import { NextResponse } from "next/server";
import { ZodError, type ZodTypeAny } from "zod";
import { getCurrentUser } from "./auth";
import type { sessions, users } from "@/db/schema";

export interface ApiContext {
  user: typeof users.$inferSelect;
  session: typeof sessions.$inferSelect;
}

export function ok<T>(data: T, init?: ResponseInit): NextResponse {
  return NextResponse.json({ ok: true, data }, init);
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>): NextResponse {
  return NextResponse.json({ ok: false, error: message, ...extra }, { status });
}

export function parseBody<T extends ZodTypeAny>(schema: T, req: Request) {
  return req.json().then((body) => schema.parse(body)) as Promise<T["_output"]>;
}

export function parseQuery<T extends ZodTypeAny>(schema: T, req: Request) {
  const url = new URL(req.url);
  const obj: Record<string, string> = {};
  url.searchParams.forEach((v, k) => {
    obj[k] = v;
  });
  return schema.parse(obj) as T["_output"];
}

export function handleApiError(err: unknown): NextResponse {
  if (err instanceof ZodError) {
    return fail("Validation failed", 400, { issues: err.issues });
  }
  if (err instanceof SyntaxError) {
    return fail("Invalid JSON", 400);
  }
  console.error("[api]", err);
  return fail("Internal error", 500);
}

export async function requireAuth(): Promise<ApiContext | NextResponse> {
  const auth = await getCurrentUser();
  if (!auth) return fail("Unauthorized", 401);
  return auth;
}
