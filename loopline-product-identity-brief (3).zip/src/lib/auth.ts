import { SignJWT, jwtVerify, type JWTPayload } from "jose";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { and, eq, isNull } from "drizzle-orm";

const ACCESS_COOKIE = "pv_access";
const ACCESS_SECRET = new TextEncoder().encode(
  process.env.JWT_ACCESS_SECRET ?? "playverse-access-dev-secret-change-me",
);
const ACCESS_TTL_MINUTES = 60 * 24 * 7; // 7 days (refresh handled at session row)

export interface AccessPayload extends JWTPayload {
  sub: string; // user id
  sid: string; // session id
  iat?: number;
  exp?: number;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function issueAccessToken(userId: string, sessionId: string): Promise<string> {
  return new SignJWT({ sub: userId, sid: sessionId } satisfies AccessPayload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${ACCESS_TTL_MINUTES}m`)
    .sign(ACCESS_SECRET);
}

export async function verifyAccessToken(token: string): Promise<AccessPayload | null> {
  try {
    const { payload } = await jwtVerify(token, ACCESS_SECRET);
    return payload as AccessPayload;
  } catch {
    return null;
  }
}

export async function setAccessCookie(token: string): Promise<void> {
  const jar = await cookies();
  jar.set(ACCESS_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: ACCESS_TTL_MINUTES * 60,
  });
}

export async function clearAccessCookie(): Promise<void> {
  const jar = await cookies();
  jar.delete(ACCESS_COOKIE);
}

export async function readAccessCookie(): Promise<string | undefined> {
  const jar = await cookies();
  return jar.get(ACCESS_COOKIE)?.value;
}

/**
 * Returns the authenticated user for the current request, or null if not logged in
 * or if the session has been revoked.
 */
export async function getCurrentUser(): Promise<{
  user: typeof users.$inferSelect;
  session: typeof sessions.$inferSelect;
} | null> {
  const token = await readAccessCookie();
  if (!token) return null;
  const payload = await verifyAccessToken(token);
  if (!payload?.sub || !payload.sid) return null;

  const session = await db.query.sessions.findFirst({
    where: and(eq(sessions.id, payload.sid), isNull(sessions.revokedAt)),
  });
  if (!session || session.expiresAt < new Date()) return null;

  const user = await db.query.users.findFirst({
    where: and(eq(users.id, payload.sub), isNull(users.deletedAt)),
  });
  if (!user) return null;

  return { user, session };
}
