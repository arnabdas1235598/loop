/**
 * In-process realtime event bus. Any API route can publish an event, and any
 * SSE endpoint (or future WebSocket gateway) can subscribe to a scoped topic.
 *
 * Topics are scoped strings like:
 *   channel:<id>       – messages, typing, reactions
 *   server:<id>        – channel/member changes
 *   voice:<channelId>  – voice state changes
 *   user:<id>          – presence, friend requests
 *   game:<roomId>      – game state updates
 *
 * This is intentionally an in-memory EventEmitter so the single Node process
 * can fan out events with sub-millisecond latency. To scale horizontally, swap
 * this module for a Redis Pub/Sub adapter with the same API.
 */

import { EventEmitter } from "node:events";

type Listener = (event: RealtimeEvent) => void;

export interface RealtimeEvent {
  type: string;
  topic: string;
  payload: unknown;
  at: number;
}

class RealtimeBus {
  private emitter = new EventEmitter();

  constructor() {
    // Allow many SSE subscribers in the same process without warnings.
    this.emitter.setMaxListeners(10_000);
  }

  publish(event: Omit<RealtimeEvent, "at">): void {
    const stamped: RealtimeEvent = { ...event, at: Date.now() };
    this.emitter.emit(event.topic, stamped);
    // Wildcard listeners (used for tests / debug)
    this.emitter.emit("*", stamped);
  }

  subscribe(topic: string, listener: Listener): () => void {
    this.emitter.on(topic, listener);
    return () => this.emitter.off(topic, listener);
  }
}

// Singleton within the Node process.
const globalForBus = globalThis as typeof globalThis & { __pvBus?: RealtimeBus };
export const bus = globalForBus.__pvBus ?? new RealtimeBus();
if (process.env.NODE_ENV !== "production") {
  globalForBus.__pvBus = bus;
}

export const topics = {
  channel: (id: string) => `channel:${id}`,
  server: (id: string) => `server:${id}`,
  voice: (channelId: string) => `voice:${channelId}`,
  user: (id: string) => `user:${id}`,
  game: (roomId: string) => `game:${roomId}`,
};
