"use client";

import { create } from "zustand";
import { useEffect } from "react";

export interface PublicUser {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  bannerUrl?: string | null;
  bio?: string | null;
  customStatusText?: string | null;
  customStatusEmoji?: string | null;
  presence: "online" | "idle" | "dnd" | "invisible" | "offline";
  coins: number;
  xp: number;
  level: number;
}

export interface ServerRow {
  id: string;
  name: string;
  slug: string;
  iconUrl: string | null;
  bannerUrl: string | null;
  description: string | null;
  ownerId: string;
  isPublic: boolean;
  tags: string[];
}

export interface ChannelRow {
  id: string;
  serverId: string;
  parentId: string | null;
  name: string;
  type: "text" | "voice" | "stage" | "announcement" | "category";
  topic: string | null;
  position: number;
  isNsfw: boolean;
  slowmodeSeconds: number;
}

export interface MessageAuthor {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
}

export interface ReactionGroup {
  emoji: string;
  userIds: string[];
}

export interface MessageRow {
  id: string;
  channelId: string;
  authorId: string;
  parentId: string | null;
  body: string;
  type: "text" | "system" | "game" | "image" | "embed";
  metadata: Record<string, unknown>;
  editedAt: string | null;
  createdAt: string;
  author: MessageAuthor;
  reactions: ReactionGroup[];
}

export interface VoiceStateRow {
  id: string;
  userId: string;
  channelId: string;
  muted: boolean;
  deafened: boolean;
  cameraOn: boolean;
  streaming: boolean;
  speaking: boolean;
  joinedAt: string;
}

export interface GameRoomRow {
  id: string;
  gameSlug: string;
  channelId: string;
  hostId: string;
  status: "lobby" | "playing" | "results" | "ended";
  state: Record<string, unknown>;
  createdAt: string;
}

interface AppState {
  me: PublicUser | null;
  servers: ServerRow[];
  currentServerId: string | null;
  currentChannelId: string | null;
  channels: ChannelRow[];
  messages: MessageRow[];
  members: Array<PublicUser & { voice: VoiceStateRow | null }>;
  voiceChannelId: string | null;
  voiceStates: VoiceStateRow[];
  activeGame: GameRoomRow | null;
  sseStatus: "connecting" | "open" | "closed" | "error";

  setMe: (u: PublicUser | null) => void;
  setServers: (s: ServerRow[]) => void;
  setCurrentServer: (id: string | null) => void;
  setCurrentChannel: (id: string | null) => void;
  setChannels: (c: ChannelRow[]) => void;
  setMessages: (m: MessageRow[]) => void;
  pushMessage: (m: MessageRow) => void;
  updateMessage: (m: MessageRow) => void;
  deleteMessage: (id: string) => void;
  applyReaction: (msgId: string, emoji: string, userId: string) => void;
  setMembers: (m: AppState["members"]) => void;
  setVoiceChannel: (id: string | null) => void;
  setVoiceStates: (s: VoiceStateRow[]) => void;
  addVoiceState: (s: VoiceStateRow & { user?: PublicUser }) => void;
  removeVoiceState: (userId: string) => void;
  setActiveGame: (g: GameRoomRow | null) => void;
  setSseStatus: (s: AppState["sseStatus"]) => void;
}

export const useApp = create<AppState>((set) => ({
  me: null,
  servers: [],
  currentServerId: null,
  currentChannelId: null,
  channels: [],
  messages: [],
  members: [],
  voiceChannelId: null,
  voiceStates: [],
  activeGame: null,
  sseStatus: "closed",

  setMe: (me) => set({ me }),
  setServers: (servers) => set({ servers }),
  setCurrentServer: (id) => set({ currentServerId: id, channels: [], messages: [], members: [] }),
  setCurrentChannel: (id) => set({ currentChannelId: id, messages: [] }),
  setChannels: (channels) => set({ channels }),
  setMessages: (messages) => set({ messages }),
  pushMessage: (m) =>
    set((s) => {
      if (s.messages.find((x) => x.id === m.id)) return s;
      return { messages: [...s.messages, m] };
    }),
  updateMessage: (m) =>
    set((s) => ({
      messages: s.messages.map((x) => (x.id === m.id ? m : x)),
    })),
  deleteMessage: (id) => set((s) => ({ messages: s.messages.filter((x) => x.id !== id) })),
  applyReaction: (msgId, emoji, userId) =>
    set((s) => ({
      messages: s.messages.map((m) => {
        if (m.id !== msgId) return m;
        const existing = m.reactions.find((r) => r.emoji === emoji);
        if (!existing) {
          return { ...m, reactions: [...m.reactions, { emoji, userIds: [userId] }] };
        }
        const hasUser = existing.userIds.includes(userId);
        const nextUserIds = hasUser
          ? existing.userIds.filter((i) => i !== userId)
          : [...existing.userIds, userId];
        const nextReactions = m.reactions
          .map((r) => (r.emoji === emoji ? { ...r, userIds: nextUserIds } : r))
          .filter((r) => r.userIds.length > 0);
        return { ...m, reactions: nextReactions };
      }),
    })),
  setMembers: (members) => set({ members }),
  setVoiceChannel: (id) => set({ voiceChannelId: id, voiceStates: id ? [] : [] }),
  setVoiceStates: (voiceStates) => set({ voiceStates }),
  addVoiceState: (s) =>
    set((state) => ({
      voiceStates: [...state.voiceStates.filter((v) => v.userId !== s.userId), s],
    })),
  removeVoiceState: (userId) =>
    set((state) => ({ voiceStates: state.voiceStates.filter((v) => v.userId !== userId) })),
  setActiveGame: (g) => set({ activeGame: g }),
  setSseStatus: (sseStatus) => set({ sseStatus }),
}));

/** Subscribe to a list of realtime topics via SSE and dispatch events into the store. */
export function useRealtime(topics: string[]): void {
  const {
    pushMessage,
    updateMessage,
    deleteMessage,
    applyReaction,
    addVoiceState,
    removeVoiceState,
    setActiveGame,
    setSseStatus,
    me,
  } = useApp();

  useEffect(() => {
    if (topics.length === 0) return;
    const url = `/api/live?${topics.map((t) => `topic=${encodeURIComponent(t)}`).join("&")}`;
    const es = new EventSource(url);
    setSseStatus("connecting");
    es.onopen = () => setSseStatus("open");
    es.onerror = () => setSseStatus("error");

    es.addEventListener("message.new", (e) => {
      pushMessage(JSON.parse(e.data));
    });
    es.addEventListener("message.updated", (e) => {
      updateMessage(JSON.parse(e.data));
    });
    es.addEventListener("message.deleted", (e) => {
      const { id } = JSON.parse(e.data) as { id: string };
      deleteMessage(id);
    });
    es.addEventListener("message.reaction", (e) => {
      const { messageId, emoji, userId } = JSON.parse(e.data) as {
        messageId: string;
        emoji: string;
        userId: string;
      };
      applyReaction(messageId, emoji, userId);
    });
    es.addEventListener("voice.joined", (e) => {
      const { state, user } = JSON.parse(e.data) as { state: VoiceStateRow; user: PublicUser };
      addVoiceState({ ...state, user });
    });
    es.addEventListener("voice.left", (e) => {
      const { userId } = JSON.parse(e.data) as { userId: string };
      removeVoiceState(userId);
    });
    es.addEventListener("game.started", (e) => {
      const data = JSON.parse(e.data) as { room: GameRoomRow };
      if (data.room) setActiveGame(data.room);
    });
    es.addEventListener("game.state", (e) => {
      const data = JSON.parse(e.data) as { room: GameRoomRow };
      if (data.room) setActiveGame(data.room);
    });
    es.addEventListener("game.ended", (e) => {
      const data = JSON.parse(e.data) as { room: GameRoomRow };
      if (data.room) setActiveGame(data.room);
    });

    return () => {
      es.close();
      setSseStatus("closed");
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [topics.join("|"), me?.id]);
}

/** Lightweight fetch wrapper that throws on non-2xx. */
export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    credentials: "include",
    headers: { "content-type": "application/json", ...(init?.headers ?? {}) },
    ...init,
  });
  const json = (await res.json().catch(() => null)) as
    | { ok: boolean; data?: T; error?: string }
    | null;
  if (!res.ok || !json?.ok) {
    throw new Error(json?.error ?? `Request failed (${res.status})`);
  }
  return json.data as T;
}
