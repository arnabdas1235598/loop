"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  api,
  useApp,
  useRealtime,
  type ChannelRow,
  type MessageRow,
  type PublicUser,
  type ServerRow,
} from "@/store/appStore";
import { ServerRail } from "./components/ServerRail";
import { ChannelSidebar } from "./components/ChannelSidebar";
import { ChatArea } from "./components/ChatArea";
import { MemberList } from "./components/MemberList";
import { VoiceRoom } from "./components/VoiceRoom";
import { TopBar } from "./components/TopBar";

export function AppShell({ me }: { me: PublicUser }) {
  const router = useRouter();
  const {
    setMe,
    servers,
    setServers,
    currentServerId,
    setCurrentServer,
    currentChannelId,
    setCurrentChannel,
    channels,
    setChannels,
    setMessages,
    setMembers,
    setVoiceStates,
    setActiveGame,
  } = useApp();

  const [loading, setLoading] = useState(true);

  // Persist current user
  useEffect(() => {
    setMe(me);
  }, [me, setMe]);

  // Load servers on mount
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const list = await api<ServerRow[]>("/api/servers");
        if (cancelled) return;
        setServers(list);
        if (list.length > 0 && !currentServerId) {
          setCurrentServer(list[0].id);
        }
      } catch (err) {
        console.error(err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [me, setServers, setCurrentServer, currentServerId]);

  // Load channels for current server
  useEffect(() => {
    if (!currentServerId) return;
    let cancelled = false;
    (async () => {
      try {
        const list = await api<ChannelRow[]>(`/api/servers/${currentServerId}/channels`);
        if (cancelled) return;
        setChannels(list);
        // Auto-select first text channel
        if (!currentChannelId || !list.find((c) => c.id === currentChannelId)) {
          const firstText = list.find((c) => c.type === "text");
          if (firstText) setCurrentChannel(firstText.id);
        }
      } catch (err) {
        console.error(err);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [currentServerId, setChannels, currentChannelId, setCurrentChannel]);

  // Load messages + members when channel changes
  useEffect(() => {
    if (!currentChannelId) return;
    let cancelled = false;
    (async () => {
      try {
        const msgs = await api<MessageRow[]>(`/api/channels/${currentChannelId}/messages?limit=50`);
        if (!cancelled) setMessages(msgs);
      } catch (err) {
        console.error(err);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [currentChannelId, setMessages]);

  useEffect(() => {
    if (!currentServerId) return;
    (async () => {
      try {
        const list = await api<
          Array<PublicUser & { voice: { userId: string; channelId: string } | null }>
        >(`/api/presence?serverId=${currentServerId}`);
        setMembers(list as never);
      } catch (err) {
        console.error(err);
      }
    })();
  }, [currentServerId, setMembers]);

  // Subscribe to realtime topics for current scope
  const topics = useMemo(() => {
    const t: string[] = [];
    if (currentChannelId) t.push(`channel:${currentChannelId}`);
    if (currentServerId) t.push(`server:${currentServerId}`);
    // Voice channel subscription (for whichever voice channel the user is in OR the current one if voice)
    const currentCh = channels.find((c) => c.id === currentChannelId);
    if (currentCh?.type === "voice") t.push(`voice:${currentCh.id}`);
    const voiceCh = useApp.getState().voiceChannelId;
    if (voiceCh && !t.includes(`voice:${voiceCh}`)) t.push(`voice:${voiceCh}`);
    return t;
  }, [currentChannelId, currentServerId, channels]);
  useRealtime(topics);

  // Load active game for the current channel if voice
  const currentChannel = channels.find((c) => c.id === currentChannelId);
  useEffect(() => {
    if (currentChannel?.type !== "voice") {
      setActiveGame(null);
      return;
    }
    (async () => {
      try {
        const room = await api<{ id: string } | null>(
          `/api/games/tictactoe?channelId=${currentChannel.id}`,
        );
        setActiveGame(room as never);
      } catch {
        setActiveGame(null);
      }
    })();
  }, [currentChannel, setActiveGame]);

  // Load voice states if viewing a voice channel
  useEffect(() => {
    if (currentChannel?.type !== "voice") {
      setVoiceStates([]);
      return;
    }
    (async () => {
      try {
        const states = await api<never[]>(`/api/voice?channelId=${currentChannel.id}`);
        setVoiceStates(states);
      } catch (err) {
        console.error(err);
      }
    })();
  }, [currentChannel, setVoiceStates]);

  async function logout() {
    await api("/api/auth/logout", { method: "POST" });
    router.push("/login");
  }

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <div className="flex flex-col items-center gap-4">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1.4, repeat: Infinity, ease: "linear" }}
            className="h-10 w-10 rounded-full border-2 border-[#a855f7] border-t-transparent"
          />
          <p className="neon-text-purple text-sm font-semibold">Loading your Playverse…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <ServerRail
        servers={servers}
        currentServerId={currentServerId}
        onSelect={setCurrentServer}
        onCreateServer={async (name: string) => {
          const created = await api<ServerRow>("/api/servers", {
            method: "POST",
            body: JSON.stringify({ name }),
          });
          setServers([...servers, created]);
          setCurrentServer(created.id);
        }}
        me={me}
        onLogout={logout}
      />
      <ChannelSidebar
        server={servers.find((s) => s.id === currentServerId) ?? null}
        channels={channels}
        currentChannelId={currentChannelId}
        onSelectChannel={setCurrentChannel}
        me={me}
      />
      <main className="relative flex flex-1 flex-col overflow-hidden">
        {servers.length === 0 ? (
          <FirstRun
            onCreate={async (name) => {
              const created = await api<ServerRow>("/api/servers", {
                method: "POST",
                body: JSON.stringify({ name }),
              });
              setServers([created]);
              setCurrentServer(created.id);
            }}
            onJoin={async (code) => {
              const joined = await api<ServerRow>("/api/servers/join", {
                method: "POST",
                body: JSON.stringify({ inviteCode: code }),
              });
              setServers([...useApp.getState().servers, joined]);
              setCurrentServer(joined.id);
            }}
          />
        ) : (
          <>
            <TopBar channel={currentChannel ?? null} me={me} />
            <AnimatePresence mode="wait">
              <motion.div
                key={currentChannelId ?? "none"}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.15 }}
                className="flex flex-1 overflow-hidden"
              >
                {currentChannel?.type === "voice" ? (
                  <VoiceRoom channel={currentChannel} me={me} />
                ) : currentChannel ? (
                  <ChatArea channel={currentChannel} me={me} />
                ) : (
                  <EmptyState />
                )}
                {currentChannel && <MemberList />}
              </motion.div>
            </AnimatePresence>
          </>
        )}
      </main>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-1 items-center justify-center">
      <div className="max-w-sm text-center">
        <div className="float mb-4 text-6xl">🌌</div>
        <h2 className="neon-text-purple text-2xl font-bold">Pick a channel</h2>
        <p className="mt-2 text-sm text-[#a79fc8]">
          Choose a text or voice channel from the sidebar to start hanging out.
        </p>
      </div>
    </div>
  );
}

function FirstRun({
  onCreate,
  onJoin,
}: {
  onCreate: (name: string) => Promise<void>;
  onJoin: (inviteCode: string) => Promise<void>;
}) {
  const [mode, setMode] = useState<"choose" | "create" | "join">("choose");
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submitCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    setErr(null);
    try {
      await onCreate(name.trim());
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed to create server");
    } finally {
      setBusy(false);
    }
  }
  async function submitJoin(e: React.FormEvent) {
    e.preventDefault();
    if (!code.trim()) return;
    setBusy(true);
    setErr(null);
    try {
      await onJoin(code.trim());
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Invalid invite code");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid flex-1 place-items-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-lg rounded-3xl border border-[#4a2d8a] bg-[#1a1030]/80 p-8 shadow-[0_30px_80px_rgba(168,85,247,0.25)] backdrop-blur-xl"
      >
        <div className="text-center">
          <div className="float mb-3 text-5xl">🌌</div>
          <h2 className="neon-text-pink text-3xl font-black">Welcome to Playverse</h2>
          <p className="mt-2 text-sm text-[#a79fc8]">
            You don&apos;t belong to any servers yet. Create your own or join one with an invite
            code.
          </p>
        </div>

        {mode === "choose" && (
          <div className="mt-6 grid gap-3">
            <button
              onClick={() => setMode("create")}
              className="group flex items-center gap-4 rounded-2xl border border-[#2d1f4d] bg-[#120a22] p-4 text-left transition hover:border-[#a855f7] hover:bg-[#241742]"
            >
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-[#a855f7] to-[#ff3ec9] text-2xl">
                ✨
              </div>
              <div className="flex-1">
                <p className="font-bold text-white">Create a server</p>
                <p className="text-xs text-[#a79fc8]">
                  Start a new community. You&apos;ll be the owner.
                </p>
              </div>
              <span className="text-[#a79fc8] group-hover:text-white">→</span>
            </button>
            <button
              onClick={() => setMode("join")}
              className="group flex items-center gap-4 rounded-2xl border border-[#2d1f4d] bg-[#120a22] p-4 text-left transition hover:border-[#22d3ee] hover:bg-[#241742]"
            >
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-[#22d3ee] to-[#22f5a4] text-2xl">
                🎟️
              </div>
              <div className="flex-1">
                <p className="font-bold text-white">Join with invite code</p>
                <p className="text-xs text-[#a79fc8]">
                  Got a code from a friend? Paste it here.
                </p>
              </div>
              <span className="text-[#a79fc8] group-hover:text-white">→</span>
            </button>
          </div>
        )}

        {mode === "create" && (
          <form onSubmit={submitCreate} className="mt-6 flex flex-col gap-4">
            <label className="flex flex-col gap-1.5">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#c4b5fd]">
                Server name
              </span>
              <input
                autoFocus
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Friday Night Crew"
                className="rounded-xl border border-[#2d1f4d] bg-[#120a22] px-4 py-2.5 text-sm text-white placeholder-[#6b6191] outline-none focus:border-[#a855f7]"
              />
            </label>
            {err && (
              <div className="rounded-xl border border-red-500/40 bg-red-500/10 px-3 py-2 text-xs text-red-200">
                {err}
              </div>
            )}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setMode("choose")}
                className="flex-1 rounded-xl border border-[#2d1f4d] px-4 py-2 text-sm font-semibold text-[#a79fc8] hover:text-white"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={!name.trim() || busy}
                className="flex-1 rounded-xl bg-gradient-to-r from-[#a855f7] to-[#ff3ec9] px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                {busy ? "Creating…" : "Create server"}
              </button>
            </div>
          </form>
        )}

        {mode === "join" && (
          <form onSubmit={submitJoin} className="mt-6 flex flex-col gap-4">
            <label className="flex flex-col gap-1.5">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#c4b5fd]">
                Invite code
              </span>
              <input
                autoFocus
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="abc-1234-xyz"
                className="rounded-xl border border-[#2d1f4d] bg-[#120a22] px-4 py-2.5 font-mono text-sm text-white placeholder-[#6b6191] outline-none focus:border-[#22d3ee]"
              />
            </label>
            {err && (
              <div className="rounded-xl border border-red-500/40 bg-red-500/10 px-3 py-2 text-xs text-red-200">
                {err}
              </div>
            )}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setMode("choose")}
                className="flex-1 rounded-xl border border-[#2d1f4d] px-4 py-2 text-sm font-semibold text-[#a79fc8] hover:text-white"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={!code.trim() || busy}
                className="flex-1 rounded-xl bg-gradient-to-r from-[#22d3ee] to-[#22f5a4] px-4 py-2 text-sm font-bold text-[#0a0612] disabled:opacity-50"
              >
                {busy ? "Joining…" : "Join server"}
              </button>
            </div>
          </form>
        )}
      </motion.div>
    </div>
  );
}
