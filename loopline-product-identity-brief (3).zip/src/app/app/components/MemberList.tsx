"use client";

import { useApp } from "@/store/appStore";
import { Avatar } from "./Avatar";

export function MemberList() {
  const members = useApp((s) => s.members);

  const online = members.filter((m) => m.presence !== "offline" && m.presence !== "invisible");
  const offline = members.filter((m) => m.presence === "offline" || m.presence === "invisible");

  return (
    <aside className="hidden w-60 flex-col gap-4 overflow-y-auto border-l border-[#2d1f4d] bg-[#120a22]/70 p-4 backdrop-blur lg:flex">
      <div>
        <p className="mb-2 px-1 text-[11px] font-bold uppercase tracking-wider text-[#6b6191]">
          Online — {online.length}
        </p>
        <div className="flex flex-col gap-0.5">
          {online.map((m) => (
            <MemberRow key={m.id} member={m} />
          ))}
        </div>
      </div>
      {offline.length > 0 && (
        <div>
          <p className="mb-2 px-1 text-[11px] font-bold uppercase tracking-wider text-[#6b6191]">
            Offline — {offline.length}
          </p>
          <div className="flex flex-col gap-0.5 opacity-60">
            {offline.map((m) => (
              <MemberRow key={m.id} member={m} />
            ))}
          </div>
        </div>
      )}
    </aside>
  );
}

function MemberRow({
  member,
}: {
  member: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string | null;
    presence: string;
    customStatusText?: string | null;
    customStatusEmoji?: string | null;
    voice?: { channelId: string; muted: boolean; deafened: boolean } | null;
  };
}) {
  const presenceColor =
    member.presence === "online"
      ? "bg-[#22f5a4]"
      : member.presence === "idle"
        ? "bg-[#ffd93d]"
        : member.presence === "dnd"
          ? "bg-[#ff3ec9]"
          : "bg-[#6b6191]";

  return (
    <div className="group flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-[#1a1030]">
      <div className="relative">
        <Avatar user={member} size={32} />
        <span
          className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-[#120a22] ${presenceColor}`}
        />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-white">{member.displayName}</p>
        {member.customStatusText && (
          <p className="truncate text-[11px] text-[#a79fc8]">
            {member.customStatusEmoji && <span className="mr-1">{member.customStatusEmoji}</span>}
            {member.customStatusText}
          </p>
        )}
        {member.voice && (
          <p className="flex items-center gap-1 truncate text-[11px] text-[#22f5a4]">
            <span>🔊</span> In voice
            {member.voice.muted && <span title="Muted">🔇</span>}
            {member.voice.deafened && <span title="Deafened">🎧</span>}
          </p>
        )}
      </div>
    </div>
  );
}
