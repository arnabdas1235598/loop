"use client";

import type { ChannelRow, PublicUser } from "@/store/appStore";

export function TopBar({ channel, me }: { channel: ChannelRow | null; me: PublicUser }) {
  void me;
  return (
    <header className="flex h-14 items-center gap-3 border-b border-[#2d1f4d] bg-[#120a22]/70 px-4 backdrop-blur">
      {channel ? (
        <>
          <span className="text-xl opacity-60">{channel.type === "voice" ? "🔊" : "#"}</span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-base font-bold text-white">{channel.name}</p>
            {channel.topic && (
              <p className="truncate text-xs text-[#a79fc8]">{channel.topic}</p>
            )}
          </div>
        </>
      ) : (
        <p className="text-sm text-[#a79fc8]">Playverse</p>
      )}

      <div className="flex items-center gap-2">
        <div className="hidden items-center gap-1 rounded-full border border-[#2d1f4d] bg-[#0a0612] px-3 py-1.5 text-xs text-[#6b6191] md:flex">
          <span>⌘</span>
          <span>K</span>
        </div>
      </div>
    </header>
  );
}
