"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { PublicUser, ServerRow } from "@/store/appStore";
import { Avatar } from "./Avatar";

export function ServerRail({
  servers,
  currentServerId,
  onSelect,
  onCreateServer,
  me,
  onLogout,
}: {
  servers: ServerRow[];
  currentServerId: string | null;
  onSelect: (id: string) => void;
  onCreateServer: (name: string) => Promise<void>;
  me: PublicUser;
  onLogout: () => void;
}) {
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    await onCreateServer(name.trim());
    setName("");
    setCreating(false);
  }

  return (
    <aside className="flex w-[76px] flex-col items-center gap-2 bg-[#0a0612] py-3">
      {/* Brand */}
      <button
        type="button"
        onClick={() => onSelect(servers[0]?.id ?? "")}
        className="group relative grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-[#a855f7] to-[#ff3ec9] text-xl font-black text-white shadow-[0_8px_20px_rgba(255,62,201,0.35)] transition hover:rounded-xl"
        title="Home"
      >
        P
        <span className="pointer-events-none absolute -right-1 -top-1 h-3 w-3 animate-pulse rounded-full bg-[#22f5a4] shadow-[0_0_10px_#22f5a4]" />
      </button>

      <div className="my-1 h-px w-8 bg-gradient-to-r from-transparent via-[#4a2d8a] to-transparent" />

      {/* Servers */}
      <div className="flex flex-1 flex-col items-center gap-2 overflow-y-auto overflow-x-hidden px-1.5">
        {servers.map((s) => {
          const active = s.id === currentServerId;
          const iconText = s.iconUrl?.startsWith("emoji:")
            ? s.iconUrl.slice(6)
            : s.name.slice(0, 2).toUpperCase();
          return (
            <div key={s.id} className="relative">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => onSelect(s.id)}
                title={s.name}
                className={`grid h-12 w-12 place-items-center overflow-hidden rounded-3xl border text-sm font-bold transition ${
                  active
                    ? "rounded-xl border-[#a855f7] bg-gradient-to-br from-[#a855f7]/30 to-[#ff3ec9]/30 text-white glow-purple"
                    : "border-[#2d1f4d] bg-[#1a1030] text-[#c4b5fd] hover:rounded-xl hover:border-[#4a2d8a] hover:bg-[#241742]"
                }`}
              >
                <span className="text-xl">{iconText}</span>
              </motion.button>
              {/* Active pill */}
              <motion.span
                initial={false}
                animate={{
                  height: active ? 36 : 8,
                  opacity: active ? 1 : 0.5,
                }}
                className="absolute left-0 top-1/2 w-1 -translate-x-[10px] -translate-y-1/2 rounded-r-full bg-[#ff3ec9]"
              />
              {/* Tooltip */}
              <div className="pointer-events-none absolute left-full top-1/2 z-50 ml-3 -translate-y-1/2 whitespace-nowrap rounded-lg bg-black/90 px-3 py-1.5 text-xs font-semibold text-white opacity-0 shadow-lg transition group-hover:opacity-0">
                {s.name}
              </div>
            </div>
          );
        })}

        {/* Create server */}
        <button
          onClick={() => setCreating(true)}
          className="grid h-12 w-12 place-items-center rounded-3xl border border-dashed border-[#4a2d8a] bg-transparent text-2xl text-[#22f5a4] transition hover:rounded-xl hover:border-[#22f5a4] hover:bg-[#22f5a4]/10"
          title="Create server"
        >
          +
        </button>
      </div>

      {/* User bubble */}
      <div className="relative">
        <button
          onClick={onLogout}
          className="group relative"
          title="Click to log out"
        >
          <Avatar user={me} size={40} />
          <span
            className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-[#0a0612] ${
              me.presence === "online"
                ? "bg-[#22f5a4]"
                : me.presence === "idle"
                  ? "bg-[#ffd93d]"
                  : me.presence === "dnd"
                    ? "bg-[#ff3ec9]"
                    : "bg-[#6b6191]"
            }`}
          />
        </button>
      </div>

      {/* Create server modal */}
      <AnimatePresence>
        {creating && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 grid place-items-center bg-black/70 backdrop-blur-sm"
            onClick={() => setCreating(false)}
          >
            <motion.form
              initial={{ scale: 0.9, y: 12 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 6 }}
              onClick={(e) => e.stopPropagation()}
              onSubmit={handleCreate}
              className="w-full max-w-md rounded-3xl border border-[#4a2d8a] bg-[#1a1030] p-8 shadow-[0_30px_80px_rgba(168,85,247,0.4)]"
            >
              <h3 className="neon-text-pink text-2xl font-black">Create a server</h3>
              <p className="mt-2 text-sm text-[#a79fc8]">
                Give your crew a name. You can change everything else later.
              </p>
              <input
                autoFocus
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Neon Hangout"
                className="mt-6 w-full rounded-xl border border-[#2d1f4d] bg-[#120a22] px-4 py-3 text-white outline-none focus:border-[#a855f7] focus:shadow-[0_0_0_3px_rgba(168,85,247,0.25)]"
              />
              <div className="mt-6 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCreating(false)}
                  className="rounded-xl px-4 py-2 text-sm font-semibold text-[#a79fc8] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!name.trim()}
                  className="rounded-xl bg-gradient-to-r from-[#a855f7] to-[#ff3ec9] px-5 py-2 text-sm font-bold text-white shadow-[0_0_20px_rgba(255,62,201,0.3)] disabled:opacity-50"
                >
                  Create
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>
    </aside>
  );
}
