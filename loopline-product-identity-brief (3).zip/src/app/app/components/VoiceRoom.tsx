"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import type { ChannelRow, PublicUser, VoiceStateRow } from "@/store/appStore";
import { api, useApp } from "@/store/appStore";
import { Avatar } from "./Avatar";
import { TicTacToe } from "./TicTacToe";

export function VoiceRoom({ channel, me }: { channel: ChannelRow; me: PublicUser }) {
  const {
    voiceChannelId,
    voiceStates,
    setVoiceChannel,
    addVoiceState,
    removeVoiceState,
    activeGame,
    members,
  } = useApp();
  const [joining, setJoining] = useState(false);
  const [muted, setMuted] = useState(false);
  const [deafened, setDeafened] = useState(false);

  const inThisRoom = voiceChannelId === channel.id;

  async function join() {
    if (inThisRoom || joining) return;
    setJoining(true);
    try {
      const state = await api<VoiceStateRow>("/api/voice", {
        method: "POST",
        body: JSON.stringify({ channelId: channel.id }),
      });
      setVoiceChannel(channel.id);
      addVoiceState({
        ...state,
        user: me,
      } as never);
    } catch (err) {
      console.error(err);
    } finally {
      setJoining(false);
    }
  }

  async function leave() {
    await api(`/api/voice?channelId=${channel.id}`, { method: "DELETE" });
    removeVoiceState(me.id);
    setVoiceChannel(null);
  }

  // Resolve members present in this room
  const roomParticipants = members.filter((m) => m.voice?.channelId === channel.id);
  // Add self if in room but not yet in members list
  const selfInRoom = inThisRoom && !roomParticipants.find((p) => p.id === me.id);
  const allParticipants = selfInRoom
    ? [...roomParticipants, { ...me, voice: voiceStates.find((v) => v.userId === me.id) ?? null }]
    : roomParticipants;

  return (
    <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
      {/* Room header */}
      <div className="flex items-center justify-between border-b border-[#2d1f4d] px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-[#a855f7] to-[#ff3ec9] text-xl">
            🔊
          </div>
          <div>
            <h2 className="text-xl font-black text-white">{channel.name}</h2>
            <p className="text-xs text-[#a79fc8]">
              {allParticipants.length} in room · {channel.topic ?? "Live voice + games"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {!inThisRoom ? (
            <button
              onClick={join}
              disabled={joining}
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#22f5a4] to-[#22d3ee] px-5 py-2 text-sm font-bold text-[#0a0612] shadow-[0_0_20px_rgba(34,245,164,0.4)] transition hover:scale-105 disabled:opacity-60"
            >
              <span>🎧</span> {joining ? "Connecting…" : "Join voice"}
            </button>
          ) : (
            <button
              onClick={leave}
              className="rounded-full bg-red-500/20 px-4 py-2 text-sm font-semibold text-red-200 hover:bg-red-500/30"
            >
              ✕ Leave
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Participants grid + controls */}
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex flex-1 flex-wrap items-center justify-center gap-5 overflow-y-auto p-8">
            {allParticipants.length === 0 && (
              <div className="text-center">
                <div className="float mb-3 text-6xl">🎙️</div>
                <p className="neon-text-purple text-lg font-bold">Empty room</p>
                <p className="mt-1 text-sm text-[#a79fc8]">
                  Be the first to hop in. Others will follow.
                </p>
              </div>
            )}
            {allParticipants.map((p) => (
              <ParticipantTile key={p.id} p={p} isSelf={p.id === me.id} />
            ))}
          </div>

          {/* Voice controls */}
          {inThisRoom && (
            <div className="flex items-center justify-center gap-3 border-t border-[#2d1f4d] bg-[#120a22]/70 p-4 backdrop-blur">
              <button
                onClick={() => setMuted((v) => !v)}
                className={`grid h-11 w-11 place-items-center rounded-full text-lg transition ${
                  muted
                    ? "bg-red-500/20 text-red-300"
                    : "bg-[#1a1030] text-white hover:bg-[#241742]"
                }`}
                title={muted ? "Unmute" : "Mute"}
              >
                {muted ? "🔇" : "🎤"}
              </button>
              <button
                onClick={() => setDeafened((v) => !v)}
                className={`grid h-11 w-11 place-items-center rounded-full text-lg transition ${
                  deafened
                    ? "bg-red-500/20 text-red-300"
                    : "bg-[#1a1030] text-white hover:bg-[#241742]"
                }`}
                title={deafened ? "Undeafen" : "Deafen"}
              >
                {deafened ? "🔕" : "🎧"}
              </button>
              <button
                className="grid h-11 w-11 place-items-center rounded-full bg-[#1a1030] text-lg text-white hover:bg-[#241742]"
                title="Camera"
              >
                📹
              </button>
              <button
                className="grid h-11 w-11 place-items-center rounded-full bg-[#1a1030] text-lg text-white hover:bg-[#241742]"
                title="Share screen"
              >
                🖥️
              </button>
              <button
                onClick={leave}
                className="ml-2 rounded-full bg-red-500 px-4 py-2 text-sm font-bold text-white shadow-[0_0_20px_rgba(239,68,68,0.4)] transition hover:bg-red-600"
              >
                Leave
              </button>
            </div>
          )}
        </div>

        {/* Game sidebar */}
        <GameSidebar channel={channel} me={me} inRoom={inThisRoom} />
      </div>
    </div>
  );
}

function ParticipantTile({
  p,
  isSelf,
}: {
  p: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string | null;
    voice?: { muted?: boolean; deafened?: boolean; speaking?: boolean } | null;
  };
  isSelf: boolean;
}) {
  const speaking = p.voice?.speaking ?? false;
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`relative flex w-36 flex-col items-center gap-2 rounded-2xl border p-4 transition ${
        speaking
          ? "border-[#22f5a4] bg-[#22f5a4]/10 speaking"
          : "border-[#2d1f4d] bg-[#1a1030]/60"
      }`}
    >
      <Avatar user={p} size={72} />
      <p className="max-w-full truncate text-sm font-bold text-white">{p.displayName}</p>
      {isSelf && (
        <span className="absolute -top-2 -right-2 rounded-full bg-[#a855f7] px-2 py-0.5 text-[10px] font-bold uppercase text-white">
          You
        </span>
      )}
      <div className="flex gap-1 text-xs">
        {p.voice?.muted && <span title="Muted">🔇</span>}
        {p.voice?.deafened && <span title="Deafened">🔕</span>}
      </div>
    </motion.div>
  );
}

function GameSidebar({
  channel,
  me,
  inRoom,
}: {
  channel: ChannelRow;
  me: PublicUser;
  inRoom: boolean;
}) {
  const { activeGame, setActiveGame } = useApp();
  const [starting, setStarting] = useState(false);

  async function startGame(slug: string) {
    if (!inRoom) return;
    setStarting(true);
    try {
      const data = await api<{ room: { id: string; state: Record<string, unknown> } }>(
        `/api/games/${slug}?action=start`,
        { method: "POST", body: JSON.stringify({ channelId: channel.id }) },
      );
      setActiveGame(data.room as never);
    } catch (err) {
      console.error(err);
    } finally {
      setStarting(false);
    }
  }

  return (
    <aside className="hidden w-80 flex-col border-l border-[#2d1f4d] bg-[#120a22]/70 backdrop-blur md:flex">
      <div className="border-b border-[#2d1f4d] px-4 py-3">
        <p className="text-[11px] font-bold uppercase tracking-wider text-[#22f5a4]">
          🎮 In-room games
        </p>
        <p className="text-xs text-[#a79fc8]">Launch a game. Everyone in voice plays together.</p>
      </div>

      {activeGame && activeGame.status !== "ended" ? (
        <div className="flex flex-1 flex-col">
          {activeGame.gameSlug === "tictactoe" && <TicTacToe room={activeGame} me={me} />}
          <div className="border-t border-[#2d1f4d] p-3">
            <button
              onClick={() => setActiveGame(null)}
              className="w-full rounded-xl border border-[#2d1f4d] bg-[#1a1030] px-3 py-2 text-xs font-semibold text-[#a79fc8] hover:text-white"
            >
              Close game panel
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-1 flex-col gap-2 overflow-y-auto p-4">
          {activeGame && activeGame.status === "ended" && (
            <div className="mb-2 rounded-xl border border-[#22f5a4]/30 bg-[#22f5a4]/10 p-3 text-xs text-[#c4b5fd]">
              <p className="font-bold text-[#22f5a4]">Previous game ended</p>
              <p className="mt-1">Start a new one below.</p>
            </div>
          )}

          <GameCard
            title="Tic-Tac-Toe"
            emoji="⭕"
            description="Classic 2-player duel. Winner gets +25 coins & +50 XP."
            players="2 players"
            disabled={!inRoom || starting}
            onStart={() => startGame("tictactoe")}
            highlight
          />
          <GameCard
            title="Draw & Guess"
            emoji="🎨"
            description="One player draws, everyone else types their guess."
            players="3–8 players"
            disabled
            badge="Soon"
          />
          <GameCard
            title="Trivia Night"
            emoji="🧠"
            description="Rounds of questions with live scoring."
            players="2–20 players"
            disabled
            badge="Soon"
          />
          <GameCard
            title="UNO"
            emoji="🃏"
            description="The classic card game. +4 chaos included."
            players="2–8 players"
            disabled
            badge="Soon"
          />
          <GameCard
            title="Chess"
            emoji="♟️"
            description="Play a match while your friends spectate."
            players="2 players"
            disabled
            badge="Soon"
          />
        </div>
      )}

      {!inRoom && (
        <div className="border-t border-[#2d1f4d] bg-[#1a1030]/60 p-3 text-xs text-[#a79fc8]">
          <p className="font-semibold text-[#ffd93d]">🔒 Join voice to play</p>
          <p className="mt-1">Games are tied to the voice room. Click “Join voice” first.</p>
        </div>
      )}
    </aside>
  );
}

function GameCard({
  title,
  emoji,
  description,
  players,
  disabled,
  onStart,
  badge,
  highlight,
}: {
  title: string;
  emoji: string;
  description: string;
  players: string;
  disabled?: boolean;
  onStart?: () => void;
  badge?: string;
  highlight?: boolean;
}) {
  return (
    <div
      className={`group relative rounded-2xl border p-4 transition ${
        highlight
          ? "border-[#a855f7] bg-gradient-to-br from-[#241742] to-[#1a1030] glow-purple"
          : "border-[#2d1f4d] bg-[#1a1030]/60"
      } ${disabled && !highlight ? "opacity-60" : ""}`}
    >
      {badge && (
        <span className="absolute -top-2 right-3 rounded-full bg-[#ffd93d] px-2 py-0.5 text-[10px] font-bold uppercase text-[#0a0612]">
          {badge}
        </span>
      )}
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#0a0612] text-2xl">{emoji}</div>
        <div>
          <p className="font-bold text-white">{title}</p>
          <p className="text-[11px] text-[#a79fc8]">{players}</p>
        </div>
      </div>
      <p className="mt-2 text-xs text-[#a79fc8]">{description}</p>
      {onStart && (
        <button
          disabled={disabled}
          onClick={onStart}
          className="mt-3 w-full rounded-xl bg-gradient-to-r from-[#a855f7] to-[#ff3ec9] px-3 py-2 text-sm font-bold text-white shadow-[0_0_16px_rgba(255,62,201,0.3)] disabled:opacity-50"
        >
          Start game
        </button>
      )}
    </div>
  );
}
