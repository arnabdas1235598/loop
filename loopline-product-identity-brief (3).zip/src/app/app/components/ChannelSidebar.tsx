"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import type { ChannelRow, PublicUser, ServerRow } from "@/store/appStore";
import { api, useApp } from "@/store/appStore";
import { Avatar } from "./Avatar";

export function ChannelSidebar({
  server,
  channels,
  currentChannelId,
  onSelectChannel,
  me,
}: {
  server: ServerRow | null;
  channels: ChannelRow[];
  currentChannelId: string | null;
  onSelectChannel: (id: string) => void;
  me: PublicUser;
}) {
  const { voiceChannelId } = useApp();
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [type, setType] = useState<"text" | "voice">("text");

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!server || !name.trim()) return;
    await api(`/api/servers/${server.id}/channels`, {
      method: "POST",
      body: JSON.stringify({ name: name.trim(), type }),
    });
    // parent will refetch
    setName("");
    setCreating(false);
  }

  const textChannels = channels.filter((c) => c.type === "text" || c.type === "announcement");
  const voiceChannels = channels.filter((c) => c.type === "voice" || c.type === "stage");

  return (
    <aside className="flex w-64 flex-col border-r border-[#2d1f4d] bg-[#120a22]/70 backdrop-blur">
      {/* Server header */}
      <div className="flex h-14 items-center gap-2 border-b border-[#2d1f4d] px-4">
        <div className="flex flex-1 items-center gap-2 overflow-hidden">
          <span className="truncate text-base font-bold text-white">
            {server?.name ?? "Loading…"}
          </span>
          {server?.isPublic && (
            <span className="rounded-full bg-[#22f5a4]/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#22f5a4]">
              Public
            </span>
          )}
        </div>
        <span className="text-[#6b6191]">▾</span>
      </div>

      {/* Channel list */}
      <div className="flex-1 overflow-y-auto px-2 py-3">
        <ChannelGroup
          label="Text Channels"
          channels={textChannels}
          currentChannelId={currentChannelId}
          onSelect={onSelectChannel}
          icon="#"
          voiceChannelId={voiceChannelId}
        />
        <div className="mt-4">
          <ChannelGroup
            label="Voice Channels"
            channels={voiceChannels}
            currentChannelId={currentChannelId}
            onSelect={onSelectChannel}
            icon="🔊"
            voiceChannelId={voiceChannelId}
          />
        </div>

        <button
          onClick={() => setCreating(true)}
          className="mt-4 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-[#a79fc8] transition hover:bg-[#1a1030] hover:text-white"
        >
          <span className="text-lg">+</span>
          <span>Create channel</span>
        </button>
      </div>

      {/* Voice bar (pinned bottom) */}
      <VoiceBar />

      {/* User bar */}
      <div className="flex items-center gap-2 border-t border-[#2d1f4d] bg-[#0a0612] px-3 py-2">
        <Avatar user={me} size={32} />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-white">{me.displayName}</p>
          <p className="truncate text-[11px] text-[#a79fc8]">@{me.username}</p>
        </div>
        <div className="flex gap-1 text-[#a79fc8]">
          <button className="rounded p-1 hover:bg-[#1a1030]" title="Mute">
            🎤
          </button>
          <button className="rounded p-1 hover:bg-[#1a1030]" title="Deafen">
            🎧
          </button>
        </div>
      </div>

      {/* Create modal */}
      {creating && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-50 grid place-items-center bg-black/70 backdrop-blur-sm"
          onClick={() => setCreating(false)}
        >
          <motion.form
            initial={{ scale: 0.95 }}
            animate={{ scale: 1 }}
            onClick={(e) => e.stopPropagation()}
            onSubmit={handleCreate}
            className="w-full max-w-md rounded-3xl border border-[#4a2d8a] bg-[#1a1030] p-6"
          >
            <h3 className="neon-text-cyan text-xl font-black">New channel</h3>
            <div className="mt-4 flex gap-2">
              {(["text", "voice"] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`flex-1 rounded-xl border px-3 py-2 text-sm font-semibold capitalize transition ${
                    type === t
                      ? "border-[#a855f7] bg-[#a855f7]/20 text-white"
                      : "border-[#2d1f4d] text-[#a79fc8]"
                  }`}
                >
                  {t === "text" ? "# Text" : "🔊 Voice"}
                </button>
              ))}
            </div>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={type === "text" ? "new-channel" : "Cozy Corner"}
              className="mt-4 w-full rounded-xl border border-[#2d1f4d] bg-[#120a22] px-4 py-2.5 text-white outline-none focus:border-[#a855f7]"
            />
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setCreating(false)}
                className="rounded-xl px-4 py-2 text-sm text-[#a79fc8]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!name.trim()}
                className="rounded-xl bg-gradient-to-r from-[#a855f7] to-[#ff3ec9] px-5 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Create
              </button>
            </div>
          </motion.form>
        </motion.div>
      )}
    </aside>
  );
}

function ChannelGroup({
  label,
  channels,
  currentChannelId,
  onSelect,
  icon,
  voiceChannelId,
}: {
  label: string;
  channels: ChannelRow[];
  currentChannelId: string | null;
  onSelect: (id: string) => void;
  icon: string;
  voiceChannelId: string | null;
}) {
  return (
    <div>
      <p className="px-3 pb-1 text-[11px] font-bold uppercase tracking-wider text-[#6b6191]">
        {label}
      </p>
      <div className="flex flex-col gap-0.5">
        {channels.map((c) => {
          const active = c.id === currentChannelId;
          const inVoice = c.type === "voice" && c.id === voiceChannelId;
          return (
            <button
              key={c.id}
              onClick={() => onSelect(c.id)}
              className={`group relative flex items-center gap-2 rounded-lg px-3 py-1.5 text-left text-sm transition ${
                active
                  ? "bg-[#241742] text-white"
                  : "text-[#a79fc8] hover:bg-[#1a1030] hover:text-white"
              }`}
            >
              <span className="text-base opacity-70 group-hover:opacity-100">{icon}</span>
              <span className="flex-1 truncate">{c.name}</span>
              {inVoice && (
                <span className="h-2 w-2 animate-pulse rounded-full bg-[#22f5a4] shadow-[0_0_8px_#22f5a4]" />
              )}
            </button>
          );
        })}
        {channels.length === 0 && (
          <p className="px-3 py-2 text-xs text-[#6b6191]">No channels yet.</p>
        )}
      </div>
    </div>
  );
}

function VoiceBar() {
  const { voiceChannelId, channels, voiceStates, setVoiceChannel, removeVoiceState, me } = useApp();
  const channel = channels.find((c) => c.id === voiceChannelId);
  void voiceStates;

  if (!channel) {
    return (
      <div className="border-t border-[#2d1f4d] bg-[#0a0612] px-3 py-2 text-xs text-[#6b6191]">
        <p className="font-semibold text-[#a79fc8]">🔇 Not in voice</p>
        <p>Click a voice channel to join.</p>
      </div>
    );
  }

  return (
    <div className="border-t border-[#2d1f4d] bg-gradient-to-r from-[#1a1030] to-[#241742] px-3 py-2">
      <p className="text-[10px] font-bold uppercase tracking-wider text-[#22f5a4]">
        🎙️ Voice connected
      </p>
      <p className="truncate text-sm font-semibold text-white">{channel.name}</p>
      <div className="mt-1 flex items-center justify-between">
        <span className="text-[11px] text-[#a79fc8]">{voiceStates.length} in room</span>
        <button
          onClick={async () => {
            await api(`/api/voice?channelId=${channel.id}`, { method: "DELETE" });
            if (me) removeVoiceState(me.id);
            setVoiceChannel(null);
          }}
          className="rounded-full bg-red-500/20 px-2 py-0.5 text-[11px] font-semibold text-red-300 hover:bg-red-500/30"
        >
          Leave
        </button>
      </div>
    </div>
  );
}
