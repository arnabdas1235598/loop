"use client";

export function Avatar({
  user,
  size = 32,
}: {
  user: { displayName: string; avatarUrl?: string | null; username: string };
  size?: number;
}) {
  const emoji = user.avatarUrl?.startsWith("emoji:") ? user.avatarUrl.slice(6) : null;
  const initials = user.displayName
    .split(/\s+/)
    .slice(0, 2)
    .map((s) => s[0]?.toUpperCase() ?? "")
    .join("");
  // Deterministic gradient from username
  const hash = Array.from(user.username).reduce((a, c) => a + c.charCodeAt(0), 0);
  const gradients = [
    "from-[#a855f7] to-[#ff3ec9]",
    "from-[#22d3ee] to-[#a855f7]",
    "from-[#ff3ec9] to-[#ffd93d]",
    "from-[#22f5a4] to-[#22d3ee]",
    "from-[#ff6b6b] to-[#a855f7]",
    "from-[#ffd93d] to-[#22f5a4]",
  ];
  const grad = gradients[hash % gradients.length];

  if (emoji) {
    return (
      <div
        className={`grid place-items-center rounded-full bg-gradient-to-br ${grad} text-white`}
        style={{ width: size, height: size, fontSize: size * 0.55 }}
      >
        <span>{emoji}</span>
      </div>
    );
  }
  return (
    <div
      className={`grid place-items-center rounded-full bg-gradient-to-br ${grad} font-bold text-white`}
      style={{ width: size, height: size, fontSize: size * 0.4 }}
    >
      {initials || "?"}
    </div>
  );
}
