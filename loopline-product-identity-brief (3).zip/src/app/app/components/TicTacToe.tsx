"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import type { GameRoomRow, PublicUser } from "@/store/appStore";
import { api, useApp } from "@/store/appStore";
import { Avatar } from "./Avatar";

interface TTTState {
  board: (string | null)[];
  turn: string;
  winner: string | null;
  winningLine: number[] | null;
  startedAt: number;
}

export function TicTacToe({ room, me }: { room: GameRoomRow; me: PublicUser }) {
  const { setActiveGame, members } = useApp();
  const state = room.state as unknown as TTTState;
  const [busy, setBusy] = useState(false);
  const [tick, setTick] = useState(0);

  // Refresh the room state periodically (in case SSE misses an event)
  useEffect(() => {
    const i = setInterval(async () => {
      try {
        const data = await api<{ room: GameRoomRow } | null>(`/api/games/tictactoe?roomId=${room.id}`);
        if (data?.room) setActiveGame(data.room);
        setTick((t) => t + 1);
      } catch {
        // ignore
      }
    }, 2000);
    return () => clearInterval(i);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room.id]);
  void tick;

  const amIPlaying = state.turn === me.id;
  const isMyTurn = amIPlaying && !state.winner;
  const isOver = !!state.winner;

  async function play(index: number) {
    if (!isMyTurn || busy) return;
    setBusy(true);
    try {
      const data = await api<{ room: GameRoomRow; state: TTTState }>(
        `/api/games/tictactoe?action=move`,
        {
          method: "POST",
          body: JSON.stringify({ roomId: room.id, index }),
        },
      );
      setActiveGame(data.room);
    } catch (err) {
      console.error(err);
    } finally {
      setBusy(false);
    }
  }

  // Resolve player names
  const playersInBoard = Array.from(new Set(state.board.filter(Boolean))) as string[];
  const resolveName = (id: string) => {
    if (id === me.id) return me.displayName;
    const m = members.find((x) => x.id === id);
    return m?.displayName ?? "Opponent";
  };

  const playerX = playersInBoard[0] ?? me.id;
  const playerO = playersInBoard[1] ?? null;
  const markFor = (id: string | null) => {
    if (!id) return null;
    return id === playerX ? "✕" : "◯";
  };
  const colorFor = (id: string | null) => {
    if (!id) return "";
    return id === playerX ? "neon-text-pink" : "neon-text-cyan";
  };

  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 p-4">
      <div className="flex w-full items-center justify-between gap-3">
        <PlayerChip
          userId={playerX}
          resolveName={resolveName}
          mark="✕"
          active={state.turn === playerX && !isOver}
          color="neon-text-pink"
        />
        <div className="text-center text-xs font-bold uppercase tracking-wider text-[#6b6191]">
          vs
        </div>
        {playerO ? (
          <PlayerChip
            userId={playerO}
            resolveName={resolveName}
            mark="◯"
            active={state.turn === playerO && !isOver}
            color="neon-text-cyan"
          />
        ) : (
          <div className="flex-1 rounded-xl border border-dashed border-[#2d1f4d] p-2 text-center text-xs text-[#a79fc8]">
            Waiting for opponent…
          </div>
        )}
      </div>

      {/* Status */}
      <div className="rounded-full border border-[#2d1f4d] bg-[#1a1030] px-4 py-1.5 text-xs font-bold">
        {isOver ? (
          state.winner === "draw" ? (
            <span className="text-[#ffd93d]">It&apos;s a draw! 🤝</span>
          ) : (
            <span className={state.winner === me.id ? "neon-text-green" : "neon-text-pink"}>
              {state.winner === me.id
                ? "You won! +25 coins 🎉"
                : `${resolveName(state.winner ?? "")} wins`}
            </span>
          )
        ) : isMyTurn ? (
          <span className="neon-text-cyan">Your turn</span>
        ) : (
          <span className="text-[#a79fc8]">Waiting for {resolveName(state.turn)}…</span>
        )}
      </div>

      {/* Board */}
      <div className="grid grid-cols-3 gap-2">
        {state.board.map((cell, i) => {
          const isWinning = state.winningLine?.includes(i);
          const isDisabled = !!cell || isOver || !isMyTurn || busy;
          return (
            <motion.button
              key={i}
              whileHover={!isDisabled ? { scale: 1.05 } : undefined}
              whileTap={!isDisabled ? { scale: 0.95 } : undefined}
              onClick={() => play(i)}
              disabled={isDisabled}
              className={`grid h-20 w-20 place-items-center rounded-2xl border-2 text-4xl font-black transition ${
                isWinning
                  ? "border-[#22f5a4] bg-[#22f5a4]/15 glow-green"
                  : "border-[#2d1f4d] bg-[#120a22]"
              } ${!isDisabled ? "hover:border-[#a855f7] hover:bg-[#1a1030]" : ""} disabled:cursor-not-allowed`}
            >
              {cell && <span className={colorFor(cell)}>{markFor(cell)}</span>}
            </motion.button>
          );
        })}
      </div>

      {isOver && (
        <button
          onClick={() => setActiveGame(null)}
          className="rounded-xl border border-[#4a2d8a] bg-[#1a1030] px-4 py-2 text-sm font-semibold text-white hover:border-[#a855f7]"
        >
          Back to games
        </button>
      )}
    </div>
  );
}

function PlayerChip({
  userId,
  resolveName,
  mark,
  active,
  color,
}: {
  userId: string;
  resolveName: (id: string) => string;
  mark: string;
  active: boolean;
  color: string;
}) {
  return (
    <div
      className={`flex flex-1 items-center gap-2 rounded-xl border p-2 transition ${
        active ? "border-[#a855f7] bg-[#a855f7]/10" : "border-[#2d1f4d] bg-[#120a22]"
      }`}
    >
      <div className={`text-2xl font-black ${color}`}>{mark}</div>
      <p className="flex-1 truncate text-sm font-semibold text-white">{resolveName(userId)}</p>
      {active && <span className="h-2 w-2 animate-pulse rounded-full bg-[#22f5a4]" />}
    </div>
  );
}
