"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { ChannelRow, MessageRow, PublicUser } from "@/store/appStore";
import { api, useApp } from "@/store/appStore";
import { Avatar } from "./Avatar";
import { formatDistanceToNowStrict } from "date-fns";

const QUICK_REACTIONS = ["👍", "❤️", "😂", "🎉", "🔥", "👀"];

export function ChatArea({ channel, me }: { channel: ChannelRow; me: PublicUser }) {
  const { messages, pushMessage } = useApp();
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const [showEmoji, setShowEmoji] = useState(false);

  // Auto-scroll to bottom when new messages arrive (only if already near bottom)
  useEffect(() => {
    const el = scrollRef.current;
    const list = listRef.current;
    if (!el || !list) return;
    const distanceFromBottom = list.scrollHeight - el.scrollTop - el.clientHeight;
    if (distanceFromBottom < 200) {
      el.scrollTo({ top: list.scrollHeight, behavior: "smooth" });
    }
  }, [messages.length]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!body.trim() || sending) return;
    setSending(true);
    try {
      // Optimistic local push
      const optimistic: MessageRow = {
        id: `local-${Date.now()}`,
        channelId: channel.id,
        authorId: me.id,
        parentId: null,
        body: body.trim(),
        type: "text",
        metadata: {},
        editedAt: null,
        createdAt: new Date().toISOString(),
        author: {
          id: me.id,
          username: me.username,
          displayName: me.displayName,
          avatarUrl: me.avatarUrl,
        },
        reactions: [],
      };
      pushMessage(optimistic);
      setBody("");
      await api(`/api/channels/${channel.id}/messages`, {
        method: "POST",
        body: JSON.stringify({ body: optimistic.body }),
      });
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  }

  async function react(msgId: string, emoji: string) {
    try {
      await api("/api/reactions", {
        method: "POST",
        body: JSON.stringify({ messageId: msgId, emoji }),
      });
    } catch (err) {
      console.error(err);
    }
  }

  async function remove(msgId: string) {
    try {
      await api(`/api/channels/${channel.id}/messages?id=${msgId}`, { method: "DELETE" });
    } catch (err) {
      console.error(err);
    }
  }

  // Group messages by author + close timestamps for compact rendering
  const grouped = useMemo(() => {
    const out: { key: string; messages: MessageRow[]; author: MessageRow["author"] }[] = [];
    for (const m of messages) {
      const prev = out[out.length - 1];
      if (
        prev &&
        prev.author.id === m.authorId &&
        new Date(m.createdAt).getTime() - new Date(prev.messages[0].createdAt).getTime() <
          5 * 60 * 1000 &&
        m.type === "text" &&
        prev.messages[0].type === "text"
      ) {
        prev.messages.push(m);
      } else {
        out.push({ key: m.id, messages: [m], author: m.author });
      }
    }
    return out;
  }, [messages]);

  return (
    <div className="flex min-w-0 flex-1 flex-col bg-transparent">
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4">
        <div ref={listRef} className="mx-auto flex max-w-4xl flex-col gap-3">
          <ChannelHeader channel={channel} />
          {grouped.length === 0 && <EmptyChat />}
          {grouped.map((group) => (
            <MessageGroup
              key={group.key}
              group={group}
              meId={me.id}
              onReact={react}
              onDelete={remove}
            />
          ))}
        </div>
      </div>

      {/* Composer */}
      <form
        onSubmit={send}
        className="border-t border-[#2d1f4d] bg-[#120a22]/70 px-4 py-3 backdrop-blur"
      >
        <div className="mx-auto flex max-w-4xl items-end gap-2 rounded-2xl border border-[#2d1f4d] bg-[#1a1030] px-3 py-2 focus-within:border-[#a855f7] focus-within:shadow-[0_0_0_3px_rgba(168,85,247,0.2)]">
          <button
            type="button"
            className="text-xl text-[#a79fc8] hover:text-white"
            title="Attach"
          >
            ⊕
          </button>
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send(e as unknown as React.FormEvent);
              }
            }}
            rows={1}
            placeholder={`Message #${channel.name}`}
            className="max-h-40 min-h-[36px] flex-1 resize-none bg-transparent text-sm text-white placeholder-[#6b6191] outline-none"
          />
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowEmoji((v) => !v)}
              className="text-xl hover:scale-110"
              title="Reactions"
            >
              😊
            </button>
            <AnimatePresence>
              {showEmoji && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  className="absolute bottom-full right-0 mb-2 flex gap-1 rounded-xl border border-[#2d1f4d] bg-[#1a1030] p-2 shadow-2xl"
                >
                  {["🎮", "🎧", "🌙", "🔥", "🏆", "💜", "⚡", "🍕"].map((e) => (
                    <button
                      key={e}
                      type="button"
                      onClick={() => {
                        setBody((b) => b + e);
                        setShowEmoji(false);
                      }}
                      className="rounded p-1 text-xl hover:bg-[#241742]"
                    >
                      {e}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <button
            type="submit"
            disabled={!body.trim() || sending}
            className="rounded-xl bg-gradient-to-r from-[#a855f7] to-[#ff3ec9] px-4 py-1.5 text-sm font-bold text-white shadow-[0_0_16px_rgba(255,62,201,0.3)] disabled:opacity-40"
          >
            Send
          </button>
        </div>
        <p className="mx-auto mt-1 max-w-4xl text-[10px] text-[#6b6191]">
          Press <kbd className="rounded bg-[#1a1030] px-1">Enter</kbd> to send ·{" "}
          <kbd className="rounded bg-[#1a1030] px-1">Shift+Enter</kbd> for newline
        </p>
      </form>
    </div>
  );
}

function ChannelHeader({ channel }: { channel: ChannelRow }) {
  return (
    <div className="mb-4 rounded-2xl border border-[#2d1f4d] bg-gradient-to-br from-[#1a1030] to-[#241742] p-6">
      <div className="flex items-center gap-3">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#a855f7]/20 text-3xl">
          #
        </span>
        <div>
          <h2 className="text-2xl font-black text-white">Welcome to #{channel.name}</h2>
          <p className="text-sm text-[#a79fc8]">
            {channel.topic ?? `This is the start of the #${channel.name} channel.`}
          </p>
        </div>
      </div>
    </div>
  );
}

function EmptyChat() {
  return (
    <div className="grid place-items-center py-16">
      <div className="text-center">
        <div className="float mb-4 text-5xl">💬</div>
        <p className="neon-text-purple text-lg font-bold">No messages yet</p>
        <p className="mt-1 text-sm text-[#a79fc8]">Send the first one — someone will reply.</p>
      </div>
    </div>
  );
}

function MessageGroup({
  group,
  meId,
  onReact,
  onDelete,
}: {
  group: { messages: MessageRow[]; author: MessageRow["author"] };
  meId: string;
  onReact: (msgId: string, emoji: string) => void;
  onDelete: (msgId: string) => void;
}) {
  const { author, messages } = group;
  const first = messages[0];
  const isSystem = first.type === "system" || first.type === "game";

  if (isSystem) {
    return (
      <div className="flex items-center gap-3 rounded-xl border border-[#2d1f4d] bg-[#1a1030]/60 px-4 py-2.5">
        <span className="text-xl">🤖</span>
        <p className="text-sm text-[#c4b5fd]">{first.body}</p>
      </div>
    );
  }

  return (
    <div className="group relative flex gap-3 rounded-lg px-2 py-1 hover:bg-[#1a1030]/40">
      <Avatar user={author} size={40} />
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-2">
          <span className="font-bold text-white">{author.displayName}</span>
          <span className="text-[11px] text-[#6b6191]">
            {formatDistanceToNowStrict(new Date(first.createdAt), { addSuffix: true })}
          </span>
        </div>
        {messages.map((m) => (
          <p
            key={m.id}
            className="whitespace-pre-wrap break-words text-sm text-[#f5f3ff]/90"
          >
            <FormattedBody body={m.body} />
            {m.editedAt && <span className="ml-1 text-[10px] text-[#6b6191]">(edited)</span>}
          </p>
        ))}
        {/* Reactions */}
        {messages.some((m) => m.reactions.length > 0) && (
          <div className="mt-1 flex flex-wrap gap-1">
            {messages.flatMap((m) =>
              m.reactions.map((r) => (
                <button
                  key={`${m.id}-${r.emoji}`}
                  onClick={() => onReact(m.id, r.emoji)}
                  className={`rounded-full border px-2 py-0.5 text-xs transition ${
                    r.userIds.includes(meId)
                      ? "border-[#a855f7] bg-[#a855f7]/20 text-white"
                      : "border-[#2d1f4d] bg-[#1a1030] text-[#c4b5fd] hover:border-[#4a2d8a]"
                  }`}
                >
                  <span className="mr-1">{r.emoji}</span>
                  <span className="font-semibold">{r.userIds.length}</span>
                </button>
              )),
            )}
          </div>
        )}
      </div>

      {/* Hover actions */}
      <div className="absolute -top-3 right-2 flex items-center gap-1 rounded-lg border border-[#2d1f4d] bg-[#1a1030] px-1 py-0.5 opacity-0 shadow-xl transition group-hover:opacity-100">
        {QUICK_REACTIONS.map((e) => (
          <button
            key={e}
            type="button"
            onClick={() => onReact(first.id, e)}
            className="rounded p-1 text-sm hover:bg-[#241742]"
          >
            {e}
          </button>
        ))}
        {messages.every((m) => m.authorId === meId) && (
          <button
            type="button"
            onClick={() => messages.forEach((m) => onDelete(m.id))}
            className="rounded p-1 text-xs text-red-300 hover:bg-red-500/20"
            title="Delete"
          >
            🗑
          </button>
        )}
      </div>
    </div>
  );
}

function FormattedBody({ body }: { body: string }) {
  // Simple markdown: **bold**, `code`, _italic_
  const parts: Array<{ type: "text" | "bold" | "code" | "italic"; value: string }> = [];
  const regex = /(\*\*[^*]+\*\*|`[^`]+`|_[^_]+_)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = regex.exec(body))) {
    if (m.index > last) parts.push({ type: "text", value: body.slice(last, m.index) });
    const tok = m[0];
    if (tok.startsWith("**")) parts.push({ type: "bold", value: tok.slice(2, -2) });
    else if (tok.startsWith("`")) parts.push({ type: "code", value: tok.slice(1, -1) });
    else if (tok.startsWith("_")) parts.push({ type: "italic", value: tok.slice(1, -1) });
    last = m.index + tok.length;
  }
  if (last < body.length) parts.push({ type: "text", value: body.slice(last) });
  return (
    <>
      {parts.map((p, i) => {
        if (p.type === "bold")
          return (
            <span key={i} className="font-bold text-white">
              {p.value}
            </span>
          );
        if (p.type === "code")
          return (
            <code
              key={i}
              className="rounded bg-[#0a0612] px-1.5 py-0.5 font-mono text-[12px] text-[#ff3ec9]"
            >
              {p.value}
            </code>
          );
        if (p.type === "italic")
          return (
            <em key={i} className="italic text-[#c4b5fd]">
              {p.value}
            </em>
          );
        return <span key={i}>{p.value}</span>;
      })}
    </>
  );
}
