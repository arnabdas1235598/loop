import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { AppShell } from "./AppShell";

export const dynamic = "force-dynamic";

export default async function AppPage() {
  const auth = await getCurrentUser();
  if (!auth) redirect("/login");

  const { passwordHash: _pw, ...me } = auth.user;
  void _pw;

  return <AppShell me={me} />;
}
