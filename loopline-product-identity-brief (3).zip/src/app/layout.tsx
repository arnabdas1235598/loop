import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Playverse — Hang out. Talk. Play.",
  description:
    "A social hangout platform where friends jump into voice rooms and play mini-games together, right inside the app.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-[#0a0612] text-[#f5f3ff] antialiased">
        {children}
      </body>
    </html>
  );
}
