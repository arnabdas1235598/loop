"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import { api, useApp } from "@/store/appStore";

export default function LoginPage() {
  const router = useRouter();
  const setMe = useApp((s) => s.setMe);
  const [mode, setMode] = useState<"login" | "register">("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const fd = new FormData(e.currentTarget);
    try {
      if (mode === "login") {
        const me = await api<typeof useApp extends never ? never : never>(
          "/api/auth/login",
          {
            method: "POST",
            body: JSON.stringify({
              login: fd.get("login"),
              password: fd.get("password"),
            }),
          },
        );
        void me;
      } else {
        const username = String(fd.get("username") ?? "").toLowerCase().replace(/[^a-z0-9_]/g, "");
        await api("/api/auth/register", {
          method: "POST",
          body: JSON.stringify({
            username,
            displayName: fd.get("displayName"),
            email: fd.get("email"),
            password: fd.get("password"),
          }),
        });
      }
      router.push("/app");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  void setMe;

  return (
    <main className="relative min-h-screen overflow-hidden">
      {/* Decorative blobs */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-40 top-20 h-[480px] w-[480px] rounded-full bg-[#a855f7]/30 blur-3xl" />
        <div className="absolute right-0 top-40 h-[520px] w-[520px] rounded-full bg-[#ff3ec9]/25 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-[420px] w-[420px] rounded-full bg-[#22d3ee]/20 blur-3xl" />
      </div>

      <div className="mx-auto flex min-h-screen max-w-6xl flex-col px-6 py-8 md:flex-row md:items-center md:gap-12">
        {/* Left brand panel */}
        <section className="flex flex-1 flex-col justify-center pb-10 md:pb-0">
          <div className="inline-flex w-fit items-center gap-2 rounded-full border border-[#4a2d8a] bg-[#1a1030]/70 px-3 py-1 text-xs font-medium text-[#c4b5fd] backdrop-blur">
            <span className="h-2 w-2 animate-pulse rounded-full bg-[#22f5a4]" />
            Beta · Hang out. Talk. Play.
          </div>
          <h1 className="mt-6 text-5xl font-black leading-[1.02] tracking-tight md:text-7xl">
            <span className="neon-text-pink">Play</span>
            <span className="neon-text-purple">verse</span>
          </h1>
          <p className="mt-4 max-w-md text-lg text-[#a79fc8]">
            Your crew's private playground. Jump into voice, chat in realtime, and launch a
            multiplayer game — all in the same room. No tab switching. No lobby codes. Just
            <span className="neon-text-cyan"> friends vibing</span>.
          </p>

          <ul className="mt-8 grid max-w-md gap-3 text-sm text-[#c4b5fd]">
            {[
              ["🎮", "Play games live inside voice rooms"],
              ["🎧", "Low-latency voice with crystal-clear audio"],
              ["🌙", "Neon-dark aesthetic, smooth animations, zero friction"],
              ["🏆", "XP, coins, cosmetics — flex on your friends"],
            ].map(([icon, text]) => (
              <li
                key={text}
                className="flex items-start gap-3 rounded-xl border border-[#2d1f4d] bg-[#1a1030]/60 p-3 backdrop-blur"
              >
                <span className="text-xl">{icon}</span>
                <span>{text}</span>
              </li>
            ))}
          </ul>
        </section>

        {/* Right auth card */}
        <section className="flex flex-1 items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="w-full max-w-md rounded-3xl border border-[#4a2d8a] bg-[#1a1030]/80 p-8 shadow-[0_30px_80px_rgba(168,85,247,0.25)] backdrop-blur-xl"
          >
            <div className="mb-6 flex items-center gap-1 rounded-full border border-[#2d1f4d] bg-[#120a22] p-1">
              {(["login", "register"] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMode(m)}
                  className={`relative flex-1 rounded-full px-4 py-2 text-sm font-semibold capitalize transition ${
                    mode === m ? "text-white" : "text-[#a79fc8] hover:text-white"
                  }`}
                >
                  {mode === m && (
                    <motion.span
                      layoutId="tab-bg"
                      className="absolute inset-0 rounded-full bg-gradient-to-r from-[#a855f7] to-[#ff3ec9]"
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{m === "login" ? "Log in" : "Sign up"}</span>
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.form
                key={mode}
                onSubmit={submit}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="flex flex-col gap-4"
              >
                {mode === "login" ? (
                  <Field label="Email or username" name="login" placeholder="you@playverse.gg" />
                ) : (
                  <>
                    <Field
                      label="Username"
                      name="username"
                      placeholder="neon_rider"
                      hint="3–32 chars · a-z, 0-9, _"
                    />
                    <Field label="Display name" name="displayName" placeholder="Neon Rider" />
                    <Field label="Email" name="email" type="email" placeholder="you@playverse.gg" />
                  </>
                )}
                <Field
                  label="Password"
                  name="password"
                  type="password"
                  placeholder="at least 8 characters"
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                />

                {error && (
                  <div className="rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-2 text-sm text-red-200">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="group relative mt-2 inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#a855f7] via-[#ff3ec9] to-[#22d3ee] px-6 py-3 text-sm font-bold text-white shadow-[0_0_30px_rgba(255,62,201,0.45)] transition hover:scale-[1.02] disabled:opacity-60"
                >
                  {loading ? "Working…" : mode === "login" ? "Enter Playverse" : "Create account"}
                  <span className="transition group-hover:translate-x-1">→</span>
                </button>

                <p className="text-center text-xs text-[#a79fc8]">
                  {mode === "login" ? "New here?" : "Already a Playverser?"}{" "}
                  <button
                    type="button"
                    onClick={() => setMode(mode === "login" ? "register" : "login")}
                    className="neon-text-cyan font-semibold hover:underline"
                  >
                    {mode === "login" ? "Create an account" : "Log in"}
                  </button>
                </p>
              </motion.form>
            </AnimatePresence>

            <p className="mt-6 text-center text-[11px] text-[#6b6191]">
              By continuing you agree to Playverse&apos;s Terms &amp; Community Guidelines.
            </p>
          </motion.div>
        </section>
      </div>
    </main>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  hint,
  autoComplete,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  hint?: string;
  autoComplete?: string;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs font-semibold uppercase tracking-wider text-[#c4b5fd]">{label}</span>
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        required
        autoComplete={autoComplete}
        className="rounded-xl border border-[#2d1f4d] bg-[#120a22]/80 px-4 py-2.5 text-sm text-white placeholder-[#6b6191] outline-none transition focus:border-[#a855f7] focus:shadow-[0_0_0_3px_rgba(168,85,247,0.25)]"
      />
      {hint && <span className="text-[11px] text-[#6b6191]">{hint}</span>}
    </label>
  );
}
