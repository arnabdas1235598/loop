import { NextResponse } from "next/server";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { sql } from "drizzle-orm";
import { ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(): Promise<NextResponse> {
  const auth = await getCurrentUser();
  const [userCountRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(users);
  const [sessionCountRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(sessions);
  return ok({
    status: "ok",
    service: "playverse",
    authenticated: !!auth,
    userCount: userCountRow?.count ?? 0,
    sessionCount: sessionCountRow?.count ?? 0,
  });
}
