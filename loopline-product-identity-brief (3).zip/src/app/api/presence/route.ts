import { NextResponse } from "next/server";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { presence, serverMembers, users, voiceStates } from "@/db/schema";
import { fail, ok, requireAuth } from "@/lib/api";
import { bus, topics } from "@/lib/realtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request): Promise<NextResponse> {
  const auth = await requireAuth();
  if (auth instanceof NextResponse) return auth;

  const url = new URL(req.url);
  const serverId = url.searchParams.get("serverId");

  if (!serverId) {
    // Single user presence
    const p = await db.query.presence.findFirst({ where: eq(presence.userId, auth.user.id) });
    return ok(p ?? { userId: auth.user.id, status: "offline" });
  }

  const members = await db.query.serverMembers.findMany({
    where: and(eq(serverMembers.serverId, serverId)),
  });
  const memberIds = members.map((m) => m.userId);
  if (memberIds.length === 0) return fail("Not a member", 403);

  const [userRows, voiceRows] = await Promise.all([
    db
      .select({
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        avatarUrl: users.avatarUrl,
        presence: users.presence,
        customStatusText: users.customStatusText,
        customStatusEmoji: users.customStatusEmoji,
      })
      .from(users)
      .where(inArray(users.id, memberIds)),
    db.select().from(voiceStates).where(inArray(voiceStates.userId, memberIds)),
  ]);

  const voiceByUser = new Map(voiceRows.map((v) => [v.userId, v]));

  const enriched = userRows.map((u) => ({
    ...u,
    voice: voiceByUser.get(u.id) ?? null,
  }));

  return ok(enriched);
}

export async function POST(req: Request): Promise<NextResponse> {
  const auth = await requireAuth();
  if (auth instanceof NextResponse) return auth;

  const body = (await req.json()) as { status?: string };
  const status = (["online", "idle", "dnd", "invisible", "offline"].includes(body.status ?? "")
    ? body.status
    : "online") as "online" | "idle" | "dnd" | "invisible" | "offline";

  await db
    .update(users)
    .set({ presence: status, lastSeenAt: new Date() })
    .where(eq(users.id, auth.user.id));

  await db
    .insert(presence)
    .values({ userId: auth.user.id, status })
    .onConflictDoUpdate({ target: presence.userId, set: { status, updatedAt: new Date() } });

  bus.publish({
    type: "presence.update",
    topic: topics.user(auth.user.id),
    payload: { userId: auth.user.id, status },
  });

  return ok({ status });
}
