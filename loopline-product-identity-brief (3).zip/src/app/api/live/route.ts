import { NextResponse } from "next/server";
import { db } from "@/db";
import { bus, topics } from "@/lib/realtime";
import { requireAuth } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * SSE endpoint. Streams events for the given topic. Clients open:
 *   /api/live?topic=channel:<id>
 * and receive: `data: {"type":"message.new","payload":...}\n\n`
 *
 * Multiple topics can be subscribed to via `topic=a&topic=b`.
 */
export async function GET(req: Request): Promise<Response> {
  const auth = await requireAuth();
  if (auth instanceof NextResponse) {
    return new Response(JSON.stringify({ error: "unauthorized" }), {
      status: 401,
      headers: { "content-type": "application/json" },
    });
  }

  const url = new URL(req.url);
  const requested = url.searchParams.getAll("topic");
  if (requested.length === 0) {
    return new Response("topic query required", { status: 400 });
  }

  const stream = new TransformStream<Uint8Array, Uint8Array>();
  const writer = stream.writable.getWriter();
  const encoder = new TextEncoder();

  const send = async (data: string) => {
    try {
      await writer.write(encoder.encode(data));
    } catch {
      // client disconnected
    }
  };

  const unsubs: Array<() => void> = [];
  for (const topic of requested) {
    const unsub = bus.subscribe(topic, (event) => {
      void send(`event: ${event.type}\ndata: ${JSON.stringify(event.payload)}\n\n`);
    });
    unsubs.push(unsub);
  }

  // Keep-alive ping every 20s to prevent proxies from killing the connection
  const pingInterval = setInterval(() => {
    void send(`: ping ${Date.now()}\n\n`);
  }, 20_000);

  // Detect client disconnect
  req.signal.addEventListener("abort", () => {
    clearInterval(pingInterval);
    for (const u of unsubs) u();
    void writer.close();
  });

  // Send hello so the client knows the stream is live
  await send(
    `event: hello\ndata: ${JSON.stringify({ userId: auth.user.id, topics: requested })}\n\n`,
  );

  void db; // keep import for potential future authorization checks

  return new Response(stream.readable, {
    headers: {
      "content-type": "text/event-stream",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
      "x-accel-buffering": "no",
    },
  });
}
