import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { channels, voiceStates } from "@/db/schema";
import { fail, handleApiError, ok, parseBody, requireAuth } from "@/lib/api";
import { bus, topics } from "@/lib/realtime";

const JoinSchema = z.object({ channelId: z.string().uuid() });

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request): Promise<NextResponse> {
  const auth = await requireAuth();
  if (auth instanceof NextResponse) return auth;

  const url = new URL(req.url);
  const channelId = url.searchParams.get("channelId");
  if (!channelId) return fail("channelId required", 400);

  const states = await db.query.voiceStates.findMany({
    where: eq(voiceStates.channelId, channelId),
  });
  return ok(states);
}

export async function POST(req: Request): Promise<NextResponse> {
  try {
    const auth = await requireAuth();
    if (auth instanceof NextResponse) return auth;

    const body = await parseBody(JoinSchema, req);
    const channel = await db.query.channels.findFirst({ where: eq(channels.id, body.channelId) });
    if (!channel || channel.type !== "voice") return fail("Voice channel not found", 404);

    // Leave any other voice channel first (one voice at a time)
    const existing = await db.query.voiceStates.findFirst({
      where: eq(voiceStates.userId, auth.user.id),
    });
    if (existing) {
      await db.delete(voiceStates).where(eq(voiceStates.id, existing.id));
      bus.publish({
        type: "voice.left",
        topic: topics.voice(existing.channelId),
        payload: { userId: auth.user.id },
      });
    }

    const [state] = await db
      .insert(voiceStates)
      .values({ userId: auth.user.id, channelId: body.channelId })
      .returning();

    bus.publish({
      type: "voice.joined",
      topic: topics.voice(body.channelId),
      payload: {
        state,
        user: {
          id: auth.user.id,
          username: auth.user.username,
          displayName: auth.user.displayName,
          avatarUrl: auth.user.avatarUrl,
        },
      },
    });

    return ok(state, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(req: Request): Promise<NextResponse> {
  const auth = await requireAuth();
  if (auth instanceof NextResponse) return auth;

  const url = new URL(req.url);
  const channelId = url.searchParams.get("channelId");
  if (!channelId) return fail("channelId required", 400);

  const state = await db.query.voiceStates.findFirst({
    where: and(eq(voiceStates.userId, auth.user.id), eq(voiceStates.channelId, channelId)),
  });
  if (!state) return ok({ left: false });

  await db.delete(voiceStates).where(eq(voiceStates.id, state.id));
  bus.publish({
    type: "voice.left",
    topic: topics.voice(channelId),
    payload: { userId: auth.user.id },
  });
  return ok({ left: true });
}
