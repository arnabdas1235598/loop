import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { fail, handleApiError, ok, parseBody } from "@/lib/api";
import { hashPassword, issueAccessToken, setAccessCookie } from "@/lib/auth";

const RegisterSchema = z.object({
  username: z
    .string()
    .min(3)
    .max(32)
    .regex(/^[a-z0-9_]+$/, "Only lowercase letters, numbers, and underscore"),
  displayName: z.string().min(1).max(64),
  email: z.string().email(),
  password: z.string().min(8).max(128),
});

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request): Promise<NextResponse> {
  try {
    const body = await parseBody(RegisterSchema, req);

    const [byEmail, byUsername] = await Promise.all([
      db.query.users.findFirst({ where: and(eq(users.email, body.email), isNull(users.deletedAt)) }),
      db.query.users.findFirst({
        where: and(eq(users.username, body.username), isNull(users.deletedAt)),
      }),
    ]);
    if (byEmail) return fail("Email already registered", 409);
    if (byUsername) return fail("Username already taken", 409);

    const passwordHash = await hashPassword(body.password);
    const [user] = await db
      .insert(users)
      .values({
        username: body.username,
        displayName: body.displayName,
        email: body.email,
        passwordHash,
      })
      .returning();

    const ua = req.headers.get("user-agent") ?? null;
    const ip = req.headers.get("x-forwarded-for") ?? req.headers.get("x-real-ip") ?? null;
    const [session] = await db
      .insert(sessions)
      .values({
        userId: user.id,
        device: ua?.slice(0, 120) ?? "unknown",
        userAgent: ua,
        ip: ip?.slice(0, 60),
        expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30),
      })
      .returning();

    const token = await issueAccessToken(user.id, session.id);
    await setAccessCookie(token);

    const { passwordHash: _pw, ...safe } = user;
    void _pw;
    return ok(safe, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
