import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { fail, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(): Promise<NextResponse> {
  const auth = await getCurrentUser();
  if (!auth) return fail("Unauthorized", 401);
  const { passwordHash: _pw, ...safe } = auth.user;
  void _pw;
  return ok({ user: safe });
}
