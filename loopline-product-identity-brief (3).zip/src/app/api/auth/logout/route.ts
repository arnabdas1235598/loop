import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { clearAccessCookie, getCurrentUser } from "@/lib/auth";
import { fail, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(): Promise<NextResponse> {
  const auth = await getCurrentUser();
  if (auth) {
    await db.update(sessions).set({ revokedAt: new Date() }).where(eq(sessions.id, auth.session.id));
  }
  await clearAccessCookie();
  return ok({ loggedOut: true });
}
