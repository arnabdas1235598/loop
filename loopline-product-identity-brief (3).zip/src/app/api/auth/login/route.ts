import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq, isNull, or } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { fail, handleApiError, ok, parseBody } from "@/lib/api";
import { issueAccessToken, setAccessCookie, verifyPassword } from "@/lib/auth";

const LoginSchema = z.object({
  login: z.string().min(1),
  password: z.string().min(1),
});

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request): Promise<NextResponse> {
  try {
    const body = await parseBody(LoginSchema, req);
    const user = await db.query.users.findFirst({
      where: and(
        isNull(users.deletedAt),
        or(eq(users.email, body.login), eq(users.username, body.login)),
      ),
    });
    if (!user) return fail("Invalid credentials", 401);
    const valid = await verifyPassword(body.password, user.passwordHash);
    if (!valid) return fail("Invalid credentials", 401);

    const ua = req.headers.get("user-agent") ?? null;
    const ip = req.headers.get("x-forwarded-for") ?? req.headers.get("x-real-ip") ?? null;
    const [session] = await db
      .insert(sessions)
      .values({
        userId: user.id,
        device: ua?.slice(0, 120) ?? "unknown",
        userAgent: ua,
        ip: ip?.slice(0, 60),
        expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30),
      })
      .returning();

    const token = await issueAccessToken(user.id, session.id);
    await setAccessCookie(token);

    const { passwordHash: _pw, ...safe } = user;
    void _pw;
    return ok(safe);
  } catch (err) {
    return handleApiError(err);
  }
}
