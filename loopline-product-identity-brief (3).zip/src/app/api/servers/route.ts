import { NextResponse } from "next/server";
import { z } from "zod";
import { and, asc, eq, inArray, isNull } from "drizzle-orm";
import { db } from "@/db";
import { channels, serverMembers, servers } from "@/db/schema";
import { fail, handleApiError, ok, parseBody, requireAuth } from "@/lib/api";
import { bus, topics } from "@/lib/realtime";

const CreateServerSchema = z.object({
  name: z.string().min(2).max(64),
  description: z.string().max(500).optional(),
  isPublic: z.boolean().optional(),
  tags: z.array(z.string().max(32)).max(6).optional(),
});

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48) || "server";
}

export async function GET(): Promise<NextResponse> {
  const auth = await requireAuth();
  if (auth instanceof NextResponse) return auth;

  // All servers the user is a member of
  const memberships = await db.query.serverMembers.findMany({
    where: eq(serverMembers.userId, auth.user.id),
  });
  if (memberships.length === 0) return ok([]);

  const list = await db.query.servers.findMany({
    where: and(
      isNull(servers.deletedAt),
      inArray(
        servers.id,
        memberships.map((m) => m.serverId),
      ),
    ),
  });
  return ok(list);
}

export async function POST(req: Request): Promise<NextResponse> {
  try {
    const auth = await requireAuth();
    if (auth instanceof NextResponse) return auth;

    const body = await parseBody(CreateServerSchema, req);
    const slug = `${slugify(body.name)}-${Math.random().toString(36).slice(2, 6)}`;

    const [server] = await db
      .insert(servers)
      .values({
        name: body.name,
        slug,
        description: body.description ?? null,
        ownerId: auth.user.id,
        isPublic: body.isPublic ?? false,
        tags: body.tags ?? [],
      })
      .returning();

    // Add creator as member
    await db.insert(serverMembers).values({ serverId: server.id, userId: auth.user.id });

    // Create default channels for the new server
    await db.insert(channels).values([
      { serverId: server.id, name: "welcome", type: "text", topic: "Say hi!", position: 0 },
      { serverId: server.id, name: "general", type: "text", topic: "General chat", position: 1 },
      {
        serverId: server.id,
        name: "The Lounge",
        type: "voice",
        topic: "Hop in and chill",
        position: 2,
      },
      {
        serverId: server.id,
        name: "Game Night",
        type: "voice",
        topic: "Launch a game from here",
        position: 3,
      },
    ]);

    return ok(server, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}

export { asc, topics, bus, fail };
