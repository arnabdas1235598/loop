import { NextResponse } from "next/server";
import { z } from "zod";
import { and, asc, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { channels, serverMembers, servers } from "@/db/schema";
import { fail, handleApiError, ok, parseBody, requireAuth } from "@/lib/api";
import { bus, topics } from "@/lib/realtime";

const CreateChannelSchema = z.object({
  name: z.string().min(1).max(64),
  type: z.enum(["text", "voice", "stage", "announcement", "category"]).default("text"),
  topic: z.string().max(512).optional(),
  parentId: z.string().uuid().optional(),
});

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  ctx: { params: Promise<{ serverId: string }> },
): Promise<NextResponse> {
  const auth = await requireAuth();
  if (auth instanceof NextResponse) return auth;
  const { serverId } = await ctx.params;

  const member = await db.query.serverMembers.findFirst({
    where: and(eq(serverMembers.serverId, serverId), eq(serverMembers.userId, auth.user.id)),
  });
  if (!member) return fail("Not a member", 403);

  const list = await db.query.channels.findMany({
    where: eq(channels.serverId, serverId),
    orderBy: [asc(channels.position), asc(channels.name)],
  });
  return ok(list);
}

export async function POST(
  req: Request,
  ctx: { params: Promise<{ serverId: string }> },
): Promise<NextResponse> {
  try {
    const auth = await requireAuth();
    if (auth instanceof NextResponse) return auth;
    const { serverId } = await ctx.params;

    const server = await db.query.servers.findFirst({
      where: and(eq(servers.id, serverId), isNull(servers.deletedAt)),
    });
    if (!server) return fail("Server not found", 404);
    if (server.ownerId !== auth.user.id) return fail("Only the owner can create channels", 403);

    const body = await parseBody(CreateChannelSchema, req);

    const maxPos = await db.query.channels.findMany({ where: eq(channels.serverId, serverId) });
    const position = maxPos.reduce((m, c) => Math.max(m, c.position), -1) + 1;

    const [channel] = await db
      .insert(channels)
      .values({
        serverId,
        name: body.name.toLowerCase().replace(/\s+/g, "-").slice(0, 64),
        type: body.type,
        topic: body.topic ?? null,
        position,
        parentId: body.parentId ?? null,
      })
      .returning();

    bus.publish({ type: "channel.created", topic: topics.server(serverId), payload: channel });
    return ok(channel, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
