import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { channels, serverMembers, servers } from "@/db/schema";
import { fail, handleApiError, ok, parseBody, requireAuth } from "@/lib/api";

const JoinSchema = z.object({ inviteCode: z.string().min(1).max(64) });

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request): Promise<NextResponse> {
  try {
    const auth = await requireAuth();
    if (auth instanceof NextResponse) return auth;
    const body = await parseBody(JoinSchema, req);

    // Servers have a slug like "chill-lounge-a3x9". We accept either the full slug
    // or the last 4 chars as a short invite code.
    const code = body.inviteCode.trim().toLowerCase();
    const server = await db.query.servers.findFirst({
      where: and(
        isNull(servers.deletedAt),
        // match full slug OR short code suffix
        eq(servers.slug, code),
      ),
    });
    // Fallback: try matching by trailing segment
    const target =
      server ??
      (
        await db.query.servers.findMany({
          where: isNull(servers.deletedAt),
        })
      ).find((s) => s.slug.endsWith(code) || s.slug === code);

    if (!target) return fail("Invalid invite code", 404);
    if (!target.isPublic) return fail("This server is private", 403);

    const already = await db.query.serverMembers.findFirst({
      where: and(eq(serverMembers.serverId, target.id), eq(serverMembers.userId, auth.user.id)),
    });
    if (!already) {
      await db.insert(serverMembers).values({ serverId: target.id, userId: auth.user.id });
    }

    // Ensure the user has at least one channel to land on
    const chs = await db.query.channels.findMany({ where: eq(channels.serverId, target.id) });
    if (chs.length === 0) {
      await db.insert(channels).values([
        { serverId: target.id, name: "general", type: "text", topic: "General chat", position: 0 },
        {
          serverId: target.id,
          name: "Lounge",
          type: "voice",
          topic: "Hop in and chill",
          position: 1,
        },
      ]);
    }

    return ok(target);
  } catch (err) {
    return handleApiError(err);
  }
}
