import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { messages, reactions } from "@/db/schema";
import { fail, handleApiError, ok, parseBody, requireAuth } from "@/lib/api";
import { bus, topics } from "@/lib/realtime";

const ReactSchema = z.object({
  messageId: z.string().uuid(),
  emoji: z.string().min(1).max(16),
});

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request): Promise<NextResponse> {
  try {
    const auth = await requireAuth();
    if (auth instanceof NextResponse) return auth;
    const body = await parseBody(ReactSchema, req);

    const msg = await db.query.messages.findFirst({ where: eq(messages.id, body.messageId) });
    if (!msg) return fail("Message not found", 404);

    const existing = await db.query.reactions.findFirst({
      where: and(
        eq(reactions.messageId, body.messageId),
        eq(reactions.userId, auth.user.id),
        eq(reactions.emoji, body.emoji),
      ),
    });
    if (existing) {
      // toggle off
      await db
        .delete(reactions)
        .where(
          and(
            eq(reactions.messageId, body.messageId),
            eq(reactions.userId, auth.user.id),
            eq(reactions.emoji, body.emoji),
          ),
        );
    } else {
      await db.insert(reactions).values({
        messageId: body.messageId,
        userId: auth.user.id,
        emoji: body.emoji,
      });
    }

    bus.publish({
      type: "message.reaction",
      topic: topics.channel(msg.channelId),
      payload: { messageId: body.messageId, emoji: body.emoji, userId: auth.user.id },
    });

    return ok({ toggled: true });
  } catch (err) {
    return handleApiError(err);
  }
}
