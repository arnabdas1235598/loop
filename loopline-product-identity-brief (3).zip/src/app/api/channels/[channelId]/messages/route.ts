import { NextResponse } from "next/server";
import { z } from "zod";
import { and, desc, eq, gt, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { channels, messages, reactions, readStates, serverMembers, users } from "@/db/schema";
import { fail, handleApiError, ok, parseBody, requireAuth } from "@/lib/api";
import { bus, topics } from "@/lib/realtime";

const SendMessageSchema = z.object({
  body: z.string().min(1).max(4000),
  type: z.enum(["text", "system", "game"]).optional(),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

const EditMessageSchema = z.object({ body: z.string().min(1).max(4000) });

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function assertMember(userId: string, channelId: string) {
  const ch = await db.query.channels.findFirst({ where: eq(channels.id, channelId) });
  if (!ch) return null;
  const member = await db.query.serverMembers.findFirst({
    where: and(eq(serverMembers.serverId, ch.serverId), eq(serverMembers.userId, userId)),
  });
  if (!member) return null;
  return ch;
}

export async function GET(
  req: Request,
  ctx: { params: Promise<{ channelId: string }> },
): Promise<NextResponse> {
  const auth = await requireAuth();
  if (auth instanceof NextResponse) return auth;
  const { channelId } = await ctx.params;

  const ch = await assertMember(auth.user.id, channelId);
  if (!ch) return fail("Channel not found or not a member", 404);

  const url = new URL(req.url);
  const before = url.searchParams.get("before");
  const limit = Math.min(50, Math.max(1, parseInt(url.searchParams.get("limit") ?? "50", 10)));

  const where = and(
    eq(messages.channelId, channelId),
    isNull(messages.deletedAt),
    before ? sql`${messages.createdAt} < ${new Date(before).toISOString()}` : undefined,
  );
  const rows = await db
    .select({
      id: messages.id,
      channelId: messages.channelId,
      authorId: messages.authorId,
      parentId: messages.parentId,
      body: messages.body,
      type: messages.type,
      metadata: messages.metadata,
      editedAt: messages.editedAt,
      createdAt: messages.createdAt,
      username: users.username,
      displayName: users.displayName,
      avatarUrl: users.avatarUrl,
    })
    .from(messages)
    .innerJoin(users, eq(users.id, messages.authorId))
    .where(where)
    .orderBy(desc(messages.createdAt))
    .limit(limit);

  // Attach reactions grouped
  if (rows.length === 0) return ok([]);
  const ids = rows.map((m) => m.id);
  const rx = await db
    .select({
      messageId: reactions.messageId,
      emoji: reactions.emoji,
      userId: reactions.userId,
    })
    .from(reactions)
    .where(sql`${reactions.messageId} IN (${sql.join(ids.map((i) => sql`${i}`), sql`, `)})`);
  const rmap = new Map<string, Map<string, string[]>>();
  for (const r of rx) {
    if (!rmap.has(r.messageId)) rmap.set(r.messageId, new Map());
    const m = rmap.get(r.messageId)!;
    if (!m.has(r.emoji)) m.set(r.emoji, []);
    m.get(r.emoji)!.push(r.userId);
  }

  const enriched = rows.map((m) => ({
    id: m.id,
    channelId: m.channelId,
    authorId: m.authorId,
    parentId: m.parentId,
    body: m.body,
    type: m.type,
    metadata: m.metadata,
    editedAt: m.editedAt,
    createdAt: m.createdAt,
    author: { id: m.authorId, username: m.username, displayName: m.displayName, avatarUrl: m.avatarUrl },
    reactions: Array.from(rmap.get(m.id)?.entries() ?? []).map(([emoji, userIds]) => ({
      emoji,
      userIds,
    })),
  }));

  return ok(enriched.reverse());
}

export async function POST(
  req: Request,
  ctx: { params: Promise<{ channelId: string }> },
): Promise<NextResponse> {
  try {
    const auth = await requireAuth();
    if (auth instanceof NextResponse) return auth;
    const { channelId } = await ctx.params;

    const ch = await assertMember(auth.user.id, channelId);
    if (!ch) return fail("Channel not found or not a member", 404);

    const body = await parseBody(SendMessageSchema, req);

    const [msg] = await db
      .insert(messages)
      .values({
        channelId,
        authorId: auth.user.id,
        body: body.body,
        type: body.type ?? "text",
        metadata: body.metadata ?? {},
      })
      .returning();

    const enriched = {
      ...msg,
      author: {
        id: auth.user.id,
        username: auth.user.username,
        displayName: auth.user.displayName,
        avatarUrl: auth.user.avatarUrl,
      },
      reactions: [],
    };

    bus.publish({
      type: "message.new",
      topic: topics.channel(channelId),
      payload: enriched,
    });
    // Also bump server-level event for unread counts
    bus.publish({
      type: "server.message",
      topic: topics.server(ch.serverId),
      payload: { channelId, messageId: msg.id },
    });

    return ok(enriched, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function PATCH(
  req: Request,
  ctx: { params: Promise<{ channelId: string }> },
): Promise<NextResponse> {
  try {
    const auth = await requireAuth();
    if (auth instanceof NextResponse) return auth;
    const { channelId } = await ctx.params;

    const url = new URL(req.url);
    const messageId = url.searchParams.get("id");
    if (!messageId) return fail("id query required", 400);

    const existing = await db.query.messages.findFirst({
      where: and(eq(messages.id, messageId), eq(messages.channelId, channelId)),
    });
    if (!existing) return fail("Message not found", 404);
    if (existing.authorId !== auth.user.id) return fail("Not your message", 403);

    const body = await parseBody(EditMessageSchema, req);
    const [updated] = await db
      .update(messages)
      .set({ body: body.body, editedAt: new Date() })
      .where(eq(messages.id, messageId))
      .returning();

    bus.publish({
      type: "message.updated",
      topic: topics.channel(channelId),
      payload: updated,
    });
    return ok(updated);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(
  req: Request,
  ctx: { params: Promise<{ channelId: string }> },
): Promise<NextResponse> {
  const auth = await requireAuth();
  if (auth instanceof NextResponse) return auth;
  const { channelId } = await ctx.params;
  const url = new URL(req.url);
  const messageId = url.searchParams.get("id");
  if (!messageId) return fail("id query required", 400);

  const existing = await db.query.messages.findFirst({
    where: and(eq(messages.id, messageId), eq(messages.channelId, channelId)),
  });
  if (!existing) return fail("Message not found", 404);
  if (existing.authorId !== auth.user.id) return fail("Not your message", 403);

  await db.update(messages).set({ deletedAt: new Date() }).where(eq(messages.id, messageId));
  bus.publish({
    type: "message.deleted",
    topic: topics.channel(channelId),
    payload: { id: messageId },
  });
  return ok({ deleted: true });
}

export { users, readStates, gt };
