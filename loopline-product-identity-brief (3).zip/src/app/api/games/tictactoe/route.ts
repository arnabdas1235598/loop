import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { channels, gamePlayers, gameRooms, users } from "@/db/schema";
import { fail, handleApiError, ok, parseBody, requireAuth } from "@/lib/api";
import { bus, topics } from "@/lib/realtime";

// ---------------------------------------------------------------------------
// Tic-Tac-Toe — MVP in-app game, server-authoritative
// ---------------------------------------------------------------------------

type Board = (string | null)[];
type TTTState = {
  board: Board;
  turn: string; // user id
  winner: string | null; // user id | "draw" | null
  winningLine: number[] | null;
  startedAt: number;
};

const LINES = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

function newBoard(): Board {
  return Array(9).fill(null);
}

function evaluate(board: Board): { winner: string | null; line: number[] | null } {
  for (const line of LINES) {
    const [a, b, c] = line;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], line };
    }
  }
  if (board.every((c) => c !== null)) return { winner: "draw", line: null };
  return { winner: null, line: null };
}

const StartSchema = z.object({ channelId: z.string().uuid() });
const MoveSchema = z.object({ roomId: z.string().uuid(), index: z.number().int().min(0).max(8) });

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request): Promise<NextResponse> {
  try {
    const auth = await requireAuth();
    if (auth instanceof NextResponse) return auth;
    const url = new URL(req.url);
    const action = url.searchParams.get("action");

    if (action === "start") {
      const body = await parseBody(StartSchema, req);
      const channel = await db.query.channels.findFirst({ where: eq(channels.id, body.channelId) });
      if (!channel || channel.type !== "voice") return fail("Not a voice channel", 400);

      // End any prior active game in this channel
      const prior = await db.query.gameRooms.findFirst({
        where: and(eq(gameRooms.channelId, body.channelId), eq(gameRooms.gameSlug, "tictactoe")),
      });
      if (prior && prior.status !== "ended") {
        await db
          .update(gameRooms)
          .set({ status: "ended", endedAt: new Date() })
          .where(eq(gameRooms.id, prior.id));
      }

      const state: TTTState = {
        board: newBoard(),
        turn: auth.user.id,
        winner: null,
        winningLine: null,
        startedAt: Date.now(),
      };

      const [room] = await db
        .insert(gameRooms)
        .values({
          gameSlug: "tictactoe",
          channelId: body.channelId,
          hostId: auth.user.id,
          status: "playing",
          state: state as unknown as Record<string, unknown>,
        })
        .returning();

      await db.insert(gamePlayers).values({
        roomId: room.id,
        userId: auth.user.id,
        score: 0,
      });

      const payload = { room, state, event: "game.started" };
      bus.publish({ type: "game.started", topic: topics.game(room.id), payload });
      bus.publish({
        type: "game.started",
        topic: topics.voice(body.channelId),
        payload: { roomId: room.id, game: "tictactoe", host: auth.user.id },
      });

      // Post a system message announcing the game
      const { messages } = await import("@/db/schema");
      await db.insert(messages).values({
        channelId: body.channelId,
        authorId: auth.user.id,
        body: `🎮 ${auth.user.displayName} started a Tic-Tac-Toe game!`,
        type: "game",
        metadata: { roomId: room.id },
      });

      return ok(payload, { status: 201 });
    }

    if (action === "move") {
      const body = await parseBody(MoveSchema, req);
      const room = await db.query.gameRooms.findFirst({ where: eq(gameRooms.id, body.roomId) });
      if (!room) return fail("Game not found", 404);
      if (room.status !== "playing") return fail("Game not active", 400);

      const state = room.state as unknown as TTTState;
      if (state.turn !== auth.user.id) return fail("Not your turn", 403);
      if (state.board[body.index] !== null) return fail("Cell taken", 400);
      if (state.winner) return fail("Game already ended", 400);

      state.board[body.index] = auth.user.id;
      const { winner, line } = evaluate(state.board);
      state.winner = winner;
      state.winningLine = line;

      // Flip turn if not ended
      if (!winner) {
        const players = await db.query.gamePlayers.findMany({
          where: eq(gamePlayers.roomId, room.id),
        });
        const other = players.find((p) => p.userId !== auth.user.id);
        if (other) state.turn = other.userId;
      }

      await db
        .update(gameRooms)
        .set({
          state: state as unknown as Record<string, unknown>,
          status: winner ? "results" : "playing",
          endedAt: winner ? new Date() : undefined,
          updatedAt: new Date(),
        })
        .where(eq(gameRooms.id, room.id));

      // Credit winner with XP/coins if ended with a real winner
      if (winner && winner !== "draw") {
        const winnerUser = await db.query.users.findFirst({ where: eq(users.id, winner) });
        if (winnerUser) {
          await db
            .update(users)
            .set({ coins: winnerUser.coins + 25, xp: winnerUser.xp + 50 })
            .where(eq(users.id, winner));
        }
      }

      bus.publish({
        type: winner ? "game.ended" : "game.state",
        topic: topics.game(room.id),
        payload: { room, state, lastMove: { userId: auth.user.id, index: body.index } },
      });

      return ok({ room, state });
    }

    return fail("Unknown action", 400);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function GET(req: Request): Promise<NextResponse> {
  const url = new URL(req.url);
  const roomId = url.searchParams.get("roomId");
  const channelId = url.searchParams.get("channelId");
  if (roomId) {
    const room = await db.query.gameRooms.findFirst({ where: eq(gameRooms.id, roomId) });
    if (!room) return fail("Not found", 404);
    const players = await db.query.gamePlayers.findMany({ where: eq(gamePlayers.roomId, roomId) });
    return ok({ room, players });
  }
  if (channelId) {
    const rooms = await db.query.gameRooms.findMany({
      where: and(eq(gameRooms.channelId, channelId)),
    });
    const active = rooms.find((r) => r.status === "playing" || r.status === "results");
    return ok(active ?? null);
  }
  return fail("roomId or channelId required", 400);
}
