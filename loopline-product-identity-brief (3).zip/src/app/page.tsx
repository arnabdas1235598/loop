import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const auth = await getCurrentUser();
  if (auth) redirect("/app");
  redirect("/login");
}
