import {
  pgTable,
  uuid,
  varchar,
  text,
  timestamp,
  integer,
  boolean,
  jsonb,
  uniqueIndex,
  index,
  primaryKey,
  bigint,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// USERS & SESSIONS
// ---------------------------------------------------------------------------

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    username: varchar("username", { length: 32 }).notNull(),
    displayName: varchar("display_name", { length: 64 }).notNull(),
    email: varchar("email", { length: 255 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    avatarUrl: varchar("avatar_url", { length: 512 }),
    bannerUrl: varchar("banner_url", { length: 512 }),
    bio: varchar("bio", { length: 500 }),
    customStatusText: varchar("custom_status_text", { length: 128 }),
    customStatusEmoji: varchar("custom_status_emoji", { length: 8 }),
    presence: varchar("presence", {
      length: 16,
      enum: ["online", "idle", "dnd", "invisible", "offline"],
    })
      .notNull()
      .default("offline"),
    coins: integer("coins").notNull().default(0),
    xp: integer("xp").notNull().default(0),
    level: integer("level").notNull().default(1),
    premiumTier: varchar("premium_tier", { length: 16 }).notNull().default("free"),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => ({
    usernameUq: uniqueIndex("users_username_uq").on(t.username),
    emailUq: uniqueIndex("users_email_uq").on(t.email),
  }),
);

export const sessions = pgTable("sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  device: varchar("device", { length: 128 }),
  userAgent: text("user_agent"),
  ip: varchar("ip", { length: 64 }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------------------------------------------------------------------------
// FRIENDSHIPS & PRESENCE
// ---------------------------------------------------------------------------

export const friendships = pgTable(
  "friendships",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    friendId: uuid("friend_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    status: varchar("status", {
      length: 16,
      enum: ["pending", "accepted", "blocked"],
    })
      .notNull()
      .default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    pairUq: uniqueIndex("friendships_pair_uq").on(t.userId, t.friendId),
  }),
);

export const presence = pgTable("presence", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  status: varchar("status", {
    length: 16,
    enum: ["online", "idle", "dnd", "invisible", "offline"],
  })
    .notNull()
    .default("offline"),
  activityType: varchar("activity_type", { length: 32 }),
  activityName: varchar("activity_name", { length: 128 }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------------------------------------------------------------------------
// SERVERS
// ---------------------------------------------------------------------------

export const servers = pgTable("servers", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 64 }).notNull(),
  slug: varchar("slug", { length: 64 }).notNull(),
  iconUrl: varchar("icon_url", { length: 512 }),
  bannerUrl: varchar("banner_url", { length: 512 }),
  description: varchar("description", { length: 500 }),
  ownerId: uuid("owner_id")
    .notNull()
    .references(() => users.id, { onDelete: "restrict" }),
  region: varchar("region", { length: 32 }).notNull().default("auto"),
  isPublic: boolean("is_public").notNull().default(false),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  boostLevel: integer("boost_level").notNull().default(0),
  vanityUrl: varchar("vanity_url", { length: 64 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
});

export const serverMembers = pgTable(
  "server_members",
  {
    serverId: uuid("server_id")
      .notNull()
      .references(() => servers.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    nickname: varchar("nickname", { length: 64 }),
    joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
    muted: boolean("muted").notNull().default(false),
    deafened: boolean("deafened").notNull().default(false),
    roles: jsonb("roles").$type<string[]>().notNull().default([]),
  },
  (t) => ({
    pk: primaryKey({ columns: [t.serverId, t.userId] }),
    userIdx: index("server_members_user_idx").on(t.userId),
  }),
);

export const roles = pgTable("roles", {
  id: uuid("id").primaryKey().defaultRandom(),
  serverId: uuid("server_id")
    .notNull()
    .references(() => servers.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 64 }).notNull(),
  color: varchar("color", { length: 16 }).notNull().default("#9ca3af"),
  permissionsBitmask: bigint("permissions_bitmask", { mode: "number" })
    .notNull()
    .default(0),
  position: integer("position").notNull().default(0),
  isHoisted: boolean("is_hoisted").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------------------------------------------------------------------------
// CHANNELS
// ---------------------------------------------------------------------------

export const channels = pgTable(
  "channels",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    serverId: uuid("server_id")
      .notNull()
      .references(() => servers.id, { onDelete: "cascade" }),
    parentId: uuid("parent_id"), // category or null
    name: varchar("name", { length: 64 }).notNull(),
    type: varchar("type", {
      length: 16,
      enum: ["text", "voice", "stage", "announcement", "category"],
    })
      .notNull()
      .default("text"),
    topic: varchar("topic", { length: 512 }),
    position: integer("position").notNull().default(0),
    isNsfw: boolean("is_nsfw").notNull().default(false),
    slowmodeSeconds: integer("slowmode_seconds").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    serverIdx: index("channels_server_idx").on(t.serverId),
  }),
);

export const voiceStates = pgTable(
  "voice_states",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    channelId: uuid("channel_id")
      .notNull()
      .references(() => channels.id, { onDelete: "cascade" }),
    muted: boolean("muted").notNull().default(false),
    deafened: boolean("deafened").notNull().default(false),
    cameraOn: boolean("camera_on").notNull().default(false),
    streaming: boolean("streaming").notNull().default(false),
    speaking: boolean("speaking").notNull().default(false),
    joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    channelIdx: index("voice_states_channel_idx").on(t.channelId),
    userUq: uniqueIndex("voice_states_user_uq").on(t.userId),
  }),
);

// ---------------------------------------------------------------------------
// MESSAGES
// ---------------------------------------------------------------------------

export const messages = pgTable(
  "messages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    channelId: uuid("channel_id")
      .notNull()
      .references(() => channels.id, { onDelete: "cascade" }),
    authorId: uuid("author_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    parentId: uuid("parent_id"),
    body: text("body").notNull().default(""),
    type: varchar("type", {
      length: 32,
      enum: ["text", "system", "game", "image", "embed"],
    })
      .notNull()
      .default("text"),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
    editedAt: timestamp("edited_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => ({
    channelCreatedIdx: index("messages_channel_created_idx").on(t.channelId, t.createdAt),
  }),
);

export const reactions = pgTable(
  "reactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    messageId: uuid("message_id")
      .notNull()
      .references(() => messages.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    emoji: varchar("emoji", { length: 16 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    uniqueUq: uniqueIndex("reactions_unique_uq").on(t.messageId, t.userId, t.emoji),
  }),
);

export const readStates = pgTable(
  "read_states",
  {
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    channelId: uuid("channel_id")
      .notNull()
      .references(() => channels.id, { onDelete: "cascade" }),
    lastReadMessageId: uuid("last_read_message_id"),
    mentionCount: integer("mention_count").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    pk: primaryKey({ columns: [t.userId, t.channelId] }),
  }),
);

// ---------------------------------------------------------------------------
// GAMES
// ---------------------------------------------------------------------------

export const gameRooms = pgTable("game_rooms", {
  id: uuid("id").primaryKey().defaultRandom(),
  gameSlug: varchar("game_slug", { length: 64 }).notNull(),
  channelId: uuid("channel_id")
    .notNull()
    .references(() => channels.id, { onDelete: "cascade" }),
  hostId: uuid("host_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  status: varchar("status", {
    length: 16,
    enum: ["lobby", "playing", "results", "ended"],
  })
    .notNull()
    .default("lobby"),
  state: jsonb("state").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  endedAt: timestamp("ended_at", { withTimezone: true }),
});

export const gamePlayers = pgTable(
  "game_players",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    roomId: uuid("room_id")
      .notNull()
      .references(() => gameRooms.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    score: integer("score").notNull().default(0),
    isSpectator: boolean("is_spectator").notNull().default(false),
    joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
    leftAt: timestamp("left_at", { withTimezone: true }),
  },
  (t) => ({
    roomUserUq: uniqueIndex("game_players_room_user_uq").on(t.roomId, t.userId),
  }),
);

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Server = typeof servers.$inferSelect;
export type Channel = typeof channels.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type VoiceState = typeof voiceStates.$inferSelect;
export type GameRoom = typeof gameRooms.$inferSelect;
export type GamePlayer = typeof gamePlayers.$inferSelect;
